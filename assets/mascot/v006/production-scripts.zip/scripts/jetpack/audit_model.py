import sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'scripts/loops'));sys.path.insert(0,str(BASE/'scripts/web_assets'))
ns={'__file__':str(BASE/'scripts/loops/audit_collisions.py')}
exec(compile((BASE/'scripts/loops/audit_collisions.py').read_text().split('\nout={}')[0],ns['__file__'],'exec'),ns)
import sino_stage as SS
SS.GLB=str(BASE/'export/web/sino_v006.draco.glb')
import bpy,json
clips=['idle','idle_b','greet_wave','listening','thinking','speaking','happy_success','jet_launch','jet_hover','jet_land']
st=ns['ns']['LoopStage'](clips)
rows={}
for c in clips:
 hits=[]
 for f in range(len(st.clips[c])-1):
  st.reset_pose([(c,f/24,1)]);bpy.context.view_layer.update();v=ns['audit'](st)
  if v:hits.append({'frame':f,'pairs':v})
 rows[c]=hits;print('MODEL_COLLISION',c,len(hits),hits[:2],flush=True)
Path('/tmp/sineva-model-collisions.json').write_text(json.dumps(rows,indent=2))
