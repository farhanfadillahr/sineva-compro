"""Non-destructive v005 derivative. Run Blender -b v005.blend --python this_file."""
import bpy, bmesh, json, math, sys
from pathlib import Path
from mathutils import Matrix, Vector
BASE=Path(__file__).resolve().parents[2]
rig=bpy.data.objects['RIG-sino']
S=bpy.context.scene
FPS=S.render.fps
# The v005 cornea shell pierces closed eyelids. Remove that redundant shell;
# the eye material retains its own specular highlight and eyelids can fully occlude it.
for obj in rig.children:
    if obj.type != 'MESH' or obj.data.shape_keys: continue
    indices={i for i,slot in enumerate(obj.material_slots) if slot.material and slot.material.name=='MAT-cornea'}
    if indices:
        bm=bmesh.new();bm.from_mesh(obj.data)
        bmesh.ops.delete(bm,geom=[f for f in bm.faces if f.material_index in indices],context='FACES')
        bm.to_mesh(obj.data);bm.free();obj.data.update()

old_clips=json.loads(rig['clips'])
sys.path.insert(0,str(BASE/'scripts/web_assets'))
from sino_stage import Stage
st=Stage.__new__(Stage);st.S=S;st.rig=rig
# Repair the pre-existing right forearm/torso collision while retaining clip names,
# timing, face animation and the rest of the original body animation.
for tr in rig.animation_data.nla_tracks:tr.mute=True
for name,end in old_clips.items():
    rig.animation_data.action=bpy.data.actions[name]
    for f in range(end+1):
        S.frame_set(f);bpy.context.view_layer.update()
        w=math.sin(math.pi*f/end)**2 if name in ('greet_wave','happy_success') else 0
        st.arm_ik('R',Vector((-.22-.07*w,-.02-.10*w,.34+.23*w)),Vector((-.4,-.10-.10*w,.40)))
        st.hand_point('R',Vector((-.15-.4*w,-.2,-1+2*w)))
        if name=='thinking':
            st.arm_ik('L',Vector((.22,-.02,.34)),Vector((.4,-.10,.40)))
            st.hand_point('L',Vector((.15,-.2,-1)))
        bones=['DEF-upper_arm.R','DEF-forearm.R','DEF-hand.R']
        if name=='thinking':bones+=['DEF-upper_arm.L','DEF-forearm.L','DEF-hand.L']
        for bone in bones:
            b=rig.pose.bones[bone]
            for prop in ('location','rotation_euler','scale'):b.keyframe_insert(prop,frame=f,group=b.name)
    print('REPAIRED',name)
rig.animation_data.action=None
# Capture the first idle pose, then leave all seven source actions intact.
for tr in rig.animation_data.nla_tracks: tr.mute=tr.name!='idle'
S.frame_set(0); bpy.context.view_layer.update()
rest={b.name:b.matrix_basis.copy() for b in rig.pose.bones}
for tr in rig.animation_data.nla_tracks: tr.mute=True
rig.animation_data.action=None

def bone_parent(o, pos):
    o.parent=rig; o.parent_type='BONE'; o.parent_bone='DEF-backpack'
    bpy.context.view_layer.update()
    o.matrix_world=Matrix.Translation(Vector(pos))
    bpy.context.view_layer.update()

parts=[]; sockets=[]
for side,x in [('L',.075),('R',-.075)]:
    # A flared open ring, 16 segments. No cap to intersect the plume.
    verts=[]; faces=[]
    for z,r in [(-.03,.027),(.03,.021),(-.03,.019),(.03,.015)]:
        for i in range(16):
            a=i*math.tau/16; verts.append((r*math.cos(a),r*math.sin(a),z))
    for j,k in [(0,1),(2,3),(0,2),(1,3)]:
        for i in range(16): faces.append((j*16+i,j*16+(i+1)%16,k*16+(i+1)%16,k*16+i))
    mesh=bpy.data.meshes.new('jet_nozzle');mesh.from_pydata(verts,[],faces);mesh.update()
    o=bpy.data.objects.new('GEO-jet_nozzle_'+side,mesh);S.collection.objects.link(o)
    o.data.materials.append(bpy.data.materials['MAT-buckle'])
    o.data.materials.append(bpy.data.materials['MAT-antenna_orb'])
    for poly in mesh.polygons: poly.use_smooth=True;poly.material_index=1 if poly.index>=32 and poly.index<48 else 0
    bone_parent(o,(x,.16,.325));parts.append(o)
    fx=bpy.data.objects.new('FX-jet_'+side,None);S.collection.objects.link(fx)
    bone_parent(fx,(x,.16,.292));sockets.append(fx)

clips={'jet_launch':39,'jet_hover':30,'jet_land':24}
# Tiny rest scale: exporter must retain the geometry for animation, visually hidden at rest.
for o in parts+sockets:o.scale=(.00001,)*3

def track(obj,name):
    ad=obj.animation_data
    act=ad.action;act.name=obj.name+':'+name
    tr=ad.nla_tracks.new();tr.name=name;tr.mute=True;tr.strips.new(name,0,act)
    ad.action=None

for name,end in clips.items():
    for frame in range(end+1):
        t=frame/end
        for b in rig.pose.bones:b.matrix_basis=rest[b.name]
        root=rig.pose.bones['DEF-root']
        if name=='jet_launch':
            deploy=min(1,t/.2);anticip=math.sin(math.pi*min(1,t/.43)) if t<.43 else 0
            rise=max(0,(t-.43)/.57)**2
            height=.42*rise-.025*anticip
            thrust=min(1,max(0,(t-.3)/.15))
            airborne=rise
        elif name=='jet_hover':
            deploy=1;anticip=0;airborne=1;height=.42+.008*math.sin(math.tau*t);thrust=.8+.1*math.sin(math.tau*t)
        else:
            u=t*t*(3-2*t);height=.42*(1-u);airborne=1-u
            anticip=0;deploy=1-min(1,max(0,(t-.75)/.25));thrust=1-min(1,max(0,(t-.6)/.25))
            height-=.015*math.sin(math.pi*max(0,(t-.8)/.2)) if t>.8 else 0
        # Root local Y is the bone's vertical axis in the Blender rig.
        root.location.y+=height
        rig.pose.bones['DEF-spine.001'].rotation_euler.x+=math.radians(-6)*airborne
        for side,sign in [('L',1),('R',-1)]:
            # Arms away from the helmet and torso. No hand crosses the face.
            wrist=Vector((.22*sign,-.02,.34))+Vector((.04*sign,-.03,.04))*airborne+Vector((0,0,height))
            st.arm_ik(side,wrist,Vector((.4*sign,-.15,.4+height)))
            st.hand_point(side,(.3*sign,-.2,-1))
            rig.pose.bones['DEF-thigh.'+side].rotation_euler.x+=math.radians(12)*airborne
            rig.pose.bones['DEF-shin.'+side].rotation_euler.x+=math.radians(-16)*airborne
        for b in rig.pose.bones:
            for prop in ('location','rotation_euler','scale'):b.keyframe_insert(prop,frame=frame,group=b.name)
        for o in parts:o.scale=(max(.00001,deploy),)*3;o.keyframe_insert('scale',frame=frame)
        # The FX node's scale is the exported thrust channel; the runtime reads it directly.
        for o in sockets:o.scale=(max(.00001,thrust),)*3;o.keyframe_insert('scale',frame=frame)
    track(rig,name)
    for o in parts+sockets:track(o,name)
    # New clips share the neutral idle expression. Required by the face baker.
    face=bpy.data.actions['idle__face'].copy();face.name=name+'__face';face.use_fake_user=True
    for layer in face.layers:
      for strip in layer.strips:
       for slot in face.slots:
        bag=strip.channelbag(slot)
        if bag:
         for fc in bag.fcurves:
          v=fc.evaluate(0)
          fc.keyframe_points.clear();fc.keyframe_points.insert(0,v);fc.keyframe_points.insert(end,v)
    print('JET CLIP',name,end/FPS)
rig['clips']=json.dumps({**old_clips,**clips})
for b in rig.pose.bones:b.matrix_basis=rest[b.name]
for o in parts+sockets:o.scale=(.00001,)*3
S.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'blender/sino_master_v006_web.blend'))
print('V006 SAVED',FPS,flush=True)
