"""Straight-alpha VP9 and premultiplied HEVC, each within the hard 600,000 byte cap."""
import sys,os
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'scripts/loops'))
from encode_loops import webm,mov,poster
from post_frames import load,save,bleed
root=BASE/'export/jetpack';out=root/'web';out.mkdir(exist_ok=True)
for cut in ['L-launch','L-flyby','L-flyby-mail']:
 d=root/cut
 # Only contiguous final frames belong in the delivery. Remove the obsolete preview's extra frame.
 last=27 if cut=='L-launch' else 20
 for f in d.glob('[0-9]*.png'):
  if int(f.stem)>last:f.unlink()
 for f in sorted(d.glob('[0-9]*.png')):save(bleed(load(str(f))),str(f))
 crf,wb=webm(str(d),str(out/(cut+'.webm')),600000)
 rate,mb=mov(str(d),str(out/(cut+'.mov')),600000)
 pb=poster(str(d),str(out/(cut+'-poster.webp')))
 assert max(wb,mb)<=600000,(cut,wb,mb)
 print('DELIVERED',cut,wb,mb,pb,flush=True)
