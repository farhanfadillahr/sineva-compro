"""Render all three one-shot cuts from the v006 web model, with plasma and a short exhaust trail."""
import sys,math,os
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'scripts/loops'));sys.path.insert(0,str(BASE/'scripts/web_assets'))
import bpy
from mathutils import Vector,Matrix
import sino_stage as SS
SS.GLB=str(BASE/'export/web/sino_v006.draco.glb')
from loop_stage import LoopStage,smoothstep
import props as P
A=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
cut=A[0] if A else 'L-launch';preview='--preview' in A;audit_only='--audit-only' in A
size=(720,960) if cut=='L-launch' else (1280,540)
N=27 if cut=='L-launch' else 20
st=LoopStage(['idle','jet_launch','jet_hover','jet_land'])
P._mats.clear();st.studio(-38,shadow=False,exposure=-.4)
bpy.data.lights['fill'].energy=70;bpy.data.lights['top'].energy=50
if st.ground:st.ground.hide_render=True
st.camera(-38,fov_deg=28.8,target=(0,0,.65),half=.74 if cut=='L-launch' else .60)
# Transparent body of the flame fades at the tip, with a restrained noise variation.
def flame_mat(name,color):
 m=SS.material(name,color,emission=color);nt=m.node_tree;n=next(n for n in nt.nodes if n.type=='BSDF_PRINCIPLED')
 noise=nt.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=5
 ramp=nt.nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(.2,.2,.2,1);ramp.color_ramp.elements[1].color=(.9,.9,.9,1)
 nt.links.new(noise.outputs['Fac'],ramp.inputs[0]);nt.links.new(ramp.outputs['Color'],n.inputs['Alpha'])
 return m
outer=flame_mat('MAT-jet-plasma','teal700');inner=flame_mat('MAT-jet-core','aqua400')
flames=[]
for side in ['L','R']:
 for layer,mat,r,length in [('outer',outer,.027,.17),('inner',inner,.014,.125)]:
  bpy.ops.mesh.primitive_cone_add(vertices=16,radius1=0,radius2=r,depth=length)
  o=bpy.context.object;o.name='FX-render-'+side+'-'+layer;o.data.materials.append(mat)
  for p in o.data.polygons:p.use_smooth=True
  flames.append((o,side,length))
mail=None
if cut=='L-flyby-mail':
 # Closed teal-edged envelope, well outside the torso and helmet.
 mail=P.block_single('white',s=.07);mail.name='PROP-envelope';mail.scale=(1.4,.18,.9)
 # V-shaped fold on front, no baked text.
 curve=bpy.data.curves.new('envelope-fold','CURVE');curve.dimensions='3D';curve.bevel_depth=.002;curve.bevel_resolution=2
 poly=curve.splines.new('POLY');poly.points.add(2)
 for p,co in zip(poly.points,[(-.045,-.009,.028),(0,-.009,-.005),(.045,-.009,.028)]):p.co=(*co,1)
 fold=bpy.data.objects.new('PROP-envelope-fold',curve);st.S.collection.objects.link(fold);fold.data.materials.append(bpy.data.materials['MAT-jet-plasma']);fold.parent=mail
# Preallocate six exhaust beads; only transform/alpha values change over time.
puffs=[]
for i in range(6):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=.016)
 o=bpy.context.object;o.name='FX-trail-'+str(i);o.data.materials.append(SS.material('MAT-trail-'+str(i),'teal300',emission='teal300',alpha=.25));puffs.append(o)
# Configure Cycles once, render rectangles with matching camera aspect.
S=st.S;S.render.engine='CYCLES'
try:
 pref=bpy.context.preferences.addons['cycles'].preferences;pref.compute_device_type='METAL';pref.refresh_devices()
 for d in pref.devices:d.use=d.type=='METAL'
 S.cycles.device='GPU'
except Exception:pass
S.cycles.samples=16 if preview else 32;S.cycles.use_adaptive_sampling=True;S.cycles.adaptive_threshold=.02;S.cycles.use_denoising=True
S.cycles.max_bounces=6;S.render.film_transparent=True;S.render.resolution_x=size[0];S.render.resolution_y=size[1];S.render.resolution_percentage=50 if preview else 100
S.render.image_settings.file_format='PNG';S.render.image_settings.color_mode='RGBA';S.render.use_compositing=False;S.render.use_sequencer=False
out=BASE/'export/jetpack'/cut;out.mkdir(parents=True,exist_ok=True)
frames=[0,8,16,24,27] if preview and cut=='L-launch' else ([0,6,12,18,20] if preview else range(N+1))
audit_ns={'__file__':str(BASE/'scripts/loops/audit_collisions.py')}
exec(compile((BASE/'scripts/loops/audit_collisions.py').read_text().split('\nout={}')[0],audit_ns['__file__'],'exec'),audit_ns)
audit_rows=[]
for f in frames:
 t=f/N
 st.reset_pose([('idle',0,1)])
 # Knees compress, arms open out, then a smooth launch away from the camera.
 anticipation=math.sin(math.pi*min(1,t/.42)) if t<.42 else 0
 thrust=smoothstep(.25,.43,t)
 if cut=='L-launch':
  u=smoothstep(.40,1,t);offset=Vector((.32*u,0,2.1*u-.02*anticipation));tilt=-10*u
 else:
  u=smoothstep(0,1,t);offset=Vector((-1.65+3.5*u,0,.08+.2*math.sin(math.pi*u)));tilt=-22
 st.translate_world('DEF-root',offset)
 st.rotate_world('DEF-spine.001',(1,0,0),tilt)
 for side,sign in [('L',1),('R',-1)]:
  st.arm_ik(side,st.head_w('DEF-upper_arm.'+side)+Vector((.13*sign,-.05,-.10)),st.head_w('DEF-upper_arm.'+side)+Vector((.25*sign,-.1,-.1)))
  st.hand_point(side,(.4*sign,-.2,-1))
 st.look_at((0,-3,2))
 deploy=max(.00001,smoothstep(0,.22,t)) if cut=='L-launch' else 1
 for side in ['L','R']:bpy.data.objects['GEO-jet_nozzle_'+side].scale=(deploy,)*3
 bpy.context.view_layer.update()
 if mail:
  mail.location=st.socket_pos('L')+Vector((.03,-.025,-.035));fold.location=(0,0,0)
 for o,side,length in flames:
  pos=bpy.data.objects['FX-jet_'+side].matrix_world.to_translation()
  pulse=1+.08*math.sin(math.tau*2*t)
  o.location=pos+Vector((0,0,-length*.5));o.scale=(thrust,thrust,thrust*pulse)
 for i,o in enumerate(puffs):
  o.location=offset+Vector((-.03*i, .16, .29-.09*i));o.scale=(thrust*(1-i/7),)*3
 # Final frame is transparent: no late fragment can remain in an overlay.
 if f==N:
  for o in S.objects:
   if o.type in ('MESH','CURVE'):o.hide_render=True
 bpy.context.view_layer.update()
 hits=audit_ns['audit'](st)
 if hits:audit_rows.append({'frame':f,'pairs':hits})
 if not audit_only:
  S.render.filepath=str(out/f'{f:04d}.png');bpy.ops.render.render(write_still=True)
 print('JETFRAME',cut,f,flush=True)
import json
Path('/tmp/sineva-'+cut+'-collisions.json').write_text(json.dumps(audit_rows,indent=2))
print('CUT COLLISIONS',cut,len(audit_rows),audit_rows[:2],flush=True)
print('CUT DONE',cut,flush=True)
