"""Surface intersection guard for moving hands/arms against torso/head, and held props.
Run headless. Intentional finger grips and sewn joint seams are excluded.
"""
import sys,os,json
from pathlib import Path
import bpy
from mathutils.bvhtree import BVHTree
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
ns={'__file__':str(D/'render_loops.py'),'__name__':'audit_loop_source'}
exec(compile((D/'render_loops.py').read_text().rsplit('\nmain()',1)[0],str(D/'render_loops.py'),'exec'),ns)

def part(name):
 if any(x in name for x in ['hand.','thumb.','index.','middle.','ring.']):return 'hand'+name[-1]
 if 'forearm.' in name:return 'arm'+name[-1]
 if any(x in name for x in ['pelvis','spine','chest']):return 'torso'
 if any(x in name for x in ['head','neck']):return 'head'
 if any(x in name for x in ['thigh.','shin.','foot.','toe.']):return 'legs'
 return None

def audit(st, hand_props=False):
 deps=bpy.context.evaluated_depsgraph_get();buckets={}
 for obj in st.meshes:
  groups={g.index:part(g.name) for g in obj.vertex_groups}
  classes=[]
  for v in obj.data.vertices:
   g=max(v.groups,key=lambda g:g.weight,default=None)
   classes.append(groups.get(g.group) if g else None)
  ev=obj.evaluated_get(deps);mesh=ev.to_mesh();mesh.calc_loop_triangles();mw=ev.matrix_world
  verts=[mw@v.co for v in mesh.vertices]
  for tri in mesh.loop_triangles:
   cls=[classes[i] for i in tri.vertices]
   if cls[0] and all(c==cls[0] for c in cls):
    vs,fs=buckets.setdefault(cls[0],([],[]));n=len(vs);vs.extend(verts[i] for i in tri.vertices);fs.append((n,n+1,n+2))
  ev.to_mesh_clear()
 # Held props and furniture may touch hands, never the torso/head/legs.
 for obj in st.S.objects:
  if obj.type!='MESH' or obj in st.meshes or obj.name.startswith(('GEO-jet_', 'FX-', 'ground')):continue
  ev=obj.evaluated_get(deps);mesh=ev.to_mesh();mesh.calc_loop_triangles();mw=ev.matrix_world
  vs,fs=buckets.setdefault('props',([],[]));n=len(vs)
  vs.extend(mw@v.co for v in mesh.vertices)
  fs.extend(tuple(n+i for i in tri.vertices) for tri in mesh.loop_triangles)
  ev.to_mesh_clear()
 trees={k:BVHTree.FromPolygons(v,f,all_triangles=True) for k,(v,f) in buckets.items() if f}
 hits={}
 for a in ['handL','handR','armL','armR','props']:
  for b in (['torso','head','legs'] if a=='props' else ['torso','head']+(['props'] if hand_props else [])):
   if a in trees and b in trees:
    n=len(trees[a].overlap(trees[b]));
    if n:hits[a+' / '+b]=n
 return hits

out={}
for lid in sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ns['LOOPS']:
 loop=ns['LOOPS'][lid]();st=ns['LoopStage'](loop.clips);ns['P']._mats.clear();ctx=loop.setup(st)
 rows=[]
 for f in range(ns['N_FRAMES']):
  loop.pose(st,ctx,f/ns['N_FRAMES']);bpy.context.view_layer.update();hits=audit(st)
  if hits:rows.append({'frame':f,'pairs':hits})
 out[lid]=rows;print('COLLISIONS',lid,len(rows),rows[:3],flush=True)
Path('/tmp/sineva-loop-collisions.json').write_text(json.dumps(out,indent=2))
