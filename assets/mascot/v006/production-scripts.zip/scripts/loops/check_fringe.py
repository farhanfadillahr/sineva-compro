"""Edge check of the delivered loops: composite one frame over white and over #EAF6F6, three ways side by side
(source PNG | decoded webm | decoded mov), cropped and enlarged so a dark or white fringe shows.

  python3 -I scripts/loops/check_fringe.py <loop-id> <out.png> [--frame 0] [--crop x:y:w:h] [--zoom 4]

The webm is decoded with libvpx-vp9 (ffmpeg's native vp9 decoder ignores the alpha plane); the mov is decoded
through AVFoundation by /tmp/mov_frame (build it with: swiftc -O scripts/loops/mov_frame.swift -o /tmp/mov_frame),
because ffmpeg's hevc decoder drops the alpha layer."""
import os
import subprocess
import sys
import tempfile

BASE = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot/export/loops'
a = sys.argv[1:]
lid, out = a[0], a[1]
opt = lambda k, d: a[a.index(k) + 1] if k in a else d
frame, crop, zoom = int(opt('--frame', 0)), opt('--crop', '200:40:300:300'), int(opt('--zoom', 3))
x, y, w, h = crop.split(':')
tmp = tempfile.mkdtemp()


def ff(*args):
    subprocess.run(['ffmpeg', '-y', '-v', 'error', *args], check=True)


tiles = []
for bg in ('FFFFFF', 'EAF6F6'):
    src = f'{BASE}/{lid}/{frame:04d}.png'
    ff('-f', 'lavfi', '-i', f'color=c=0x{bg}:s=720x720', '-i', src, '-filter_complex', '[0][1]overlay=format=auto', '-frames:v', '1', f'{tmp}/s_{bg}.png')
    ff('-c:v', 'libvpx-vp9', '-i', f'{BASE}/web/{lid}.webm', '-f', 'lavfi', '-i', f'color=c=0x{bg}:s=720x720',
       '-filter_complex', f'[0:v]select=eq(n\\,{frame}),setpts=PTS-STARTPTS,format=rgba[v];[1][v]overlay=format=auto', '-frames:v', '1', f'{tmp}/w_{bg}.png')
    subprocess.run(['/tmp/mov_frame', f'{BASE}/web/{lid}.mov', str(frame), bg, f'{tmp}/m_{bg}.rgb'], check=True, capture_output=True)
    ff('-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '720x720', '-i', f'{tmp}/m_{bg}.rgb', f'{tmp}/m_{bg}.png')
    tiles += [f'{tmp}/s_{bg}.png', f'{tmp}/w_{bg}.png', f'{tmp}/m_{bg}.png']
cmd = ['ffmpeg', '-y', '-v', 'error']
for t in tiles:
    cmd += ['-i', t]
sz = int(w) * zoom
parts = [f'[{i}:v]crop={w}:{h}:{x}:{y},scale={sz}:{int(h) * zoom}:flags=neighbor[t{i}]' for i in range(6)]
layout = '|'.join(f'{(i % 3) * sz}_{(i // 3) * int(h) * zoom}' for i in range(6))
parts.append(f'{"".join(f"[t{i}]" for i in range(6))}xstack=inputs=6:layout={layout}')
subprocess.run(cmd + ['-filter_complex', ';'.join(parts), '-frames:v', '1', out], check=True)
