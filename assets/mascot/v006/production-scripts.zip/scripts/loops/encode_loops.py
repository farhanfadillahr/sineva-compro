"""Encode the loop frame sequences: WebM (VP9 + alpha), MOV (HEVC + alpha, Safari) and a WebP poster.

  python3 -I scripts/loops/encode_loops.py [loop ids ...] [--budget 900000] [--out DIR]

Reads   export/loops/<id>/NNNN.png          (post_frames.py)
Writes  export/loops/web/<id>.webm  <id>.mov  <id>-poster.webp

- webm: libvpx-vp9 constant-quality, `-b:v 0 -crf N`. N is searched upwards from CRF_START in steps of 2 and
  the first file at or under the budget wins, i.e. the best quality that fits. 900 KB is taken as 900,000
  bytes (the smaller reading of "KB").
- mov: hevc_videotoolbox with alpha (hvc1 tag, bgra input). The bitrate is searched downwards from MOV_START
  when the file is over budget. Safari plays this container; Chrome/Firefox take the webm.
  The colour is premultiplied by alpha before encoding: the decoder hands Safari a buffer tagged
  PremultipliedAlpha, so straight colour in the semi-transparent pixels (silhouette edge, shadow) composites
  too bright, a light halo on a dark page and a cyan glow in the shadow. The webm keeps straight alpha,
  which is what Chrome and Firefox expect.
- poster: frame 0 as lossy WebP with a near-lossless alpha channel, via cwebp (Pillow is not installed for the
  system python here and ffmpeg has no WebP encoder).
Prints a size table at the end.
"""
import os
import subprocess
import sys

BASE = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot/export/loops'
IDS = ['L-wave', 'L-phone', 'L-build', 'L-thumbs', 'L-confused']
CRF_START = 20
MOV_START = 2_000_000


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"{' '.join(cmd[:3])} failed:\n{r.stderr[-1500:]}")


def webm(frames, out, budget):
    crf = CRF_START
    while True:
        run(['ffmpeg', '-y', '-v', 'error', '-framerate', '24', '-i', f'{frames}/%04d.png', '-c:v', 'libvpx-vp9',
             '-pix_fmt', 'yuva420p', '-b:v', '0', '-crf', str(crf), '-row-mt', '1', '-auto-alt-ref', '0',
             '-deadline', 'good', '-cpu-used', '1', '-an', out])
        size = os.path.getsize(out)
        if size <= budget or crf >= 52:
            return crf, size
        crf += 2


def mov(frames, out, budget):
    rate = MOV_START
    while True:
        run(['ffmpeg', '-y', '-v', 'error', '-framerate', '24', '-i', f'{frames}/%04d.png', '-vf', 'format=gbrap,premultiply=inplace=1,format=bgra',
             '-c:v', 'hevc_videotoolbox', '-allow_sw', '1', '-alpha_quality', '0.75', '-vtag', 'hvc1', '-pix_fmt', 'bgra', '-b:v', str(rate), '-an', out])
        size = os.path.getsize(out)
        if size <= budget or rate <= 300_000:
            return rate, size
        rate = int(rate * 0.8)


def poster(frames, out):
    run(['cwebp', '-quiet', '-q', '88', '-alpha_q', '100', '-m', '6', '-sharp_yuv', f'{frames}/0000.png', '-o', out])
    return os.path.getsize(out)


def main():
    a = sys.argv[1:]
    budget = int(a[a.index('--budget') + 1]) if '--budget' in a else 900_000
    base = a[a.index('--out') + 1] if '--out' in a else BASE
    ids = [x for x in a if x in IDS] or IDS
    web = os.path.join(base, 'web')
    os.makedirs(web, exist_ok=True)
    rows = []
    for i in ids:
        fr = os.path.join(base, i)
        crf, ws = webm(fr, f'{web}/{i}.webm', budget)
        rate, ms = mov(fr, f'{web}/{i}.mov', budget)
        ps = poster(fr, f'{web}/{i}-poster.webp')
        rows.append((i, ws, crf, ms, rate, ps))
        print(f'{i}: webm {ws} B (crf {crf})  mov {ms} B ({rate} bps)  poster {ps} B', flush=True)
    print('\nid          webm B   crf   mov B   bitrate   poster B')
    for r in rows:
        print(f'{r[0]:<10} {r[1]:>8} {r[2]:>5} {r[3]:>8} {r[4]:>9} {r[5]:>9}')


if __name__ == '__main__':
    main()
