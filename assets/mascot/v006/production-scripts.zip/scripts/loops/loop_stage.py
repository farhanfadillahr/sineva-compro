"""Animated variant of the still-pose Stage (scripts/web_assets/sino_stage.py) for the website loops.

Stage.set_clip() freezes ONE frame of a clip and throws the NLA away. A loop needs the clips evaluated
at many times, blended, and then edited with the same bone helpers (arm_ik, hand_point, curl, look_at,
rotate_world ...) every frame. So LoopStage samples each clip once into plain per-frame bone and
shape-key tables right after the GLB import, deletes the animation data (the NLA would overwrite manual
bone edits on every frame change, same reason as in Stage), and from then on a frame is built as

    reset_pose(mix)   <- clip samples blended into the rig, shape keys included
    ...tweaks...      <- IK / head / morph helpers, all pure functions of the loop phase

Because every frame is rebuilt from the clip samples, tweaks never accumulate between frames, and a loop
is seamless as long as every tweak is a periodic function of the phase p in [0, 1).

Run through Blender (headless), see render_loops.py.
"""
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'web_assets'))

import bpy
from mathutils import Matrix, Quaternion, Vector

import sino_stage as SS
from sino_stage import Stage, FPS


# Every clip has exactly one blink, at a different time. A blend of two clips would play one of them at
# partial strength (a half-twitch); the loops place their own blink instead (render_loops.blink).
BLINK_KEYS = ('eyeBlinkLeft', 'eyeBlinkRight')


class LoopStage(Stage):
    def __init__(self, clips):
        # Same import as Stage.__init__, but without its set_clip(): that call freezes one frame and drops
        # the NLA tracks, which is exactly what has to be sampled first here.
        bpy.ops.wm.read_factory_settings(use_empty=True)
        bpy.ops.import_scene.gltf(filepath=SS.GLB)
        self.S = bpy.context.scene
        self.S.render.fps = FPS
        self.rig = next(o for o in self.S.objects if o.type == 'ARMATURE')
        self.meshes = [o for o in self.S.objects if o.type == 'MESH' and o.parent == self.rig]
        for o in list(self.S.objects):
            if o.type == 'MESH' and o.parent is None:  # importer's "Icosphere" bone shape
                bpy.data.objects.remove(o, do_unlink=True)
        self.props = []
        self.clips = {c: self._sample_clip(c) for c in clips}
        self._drop_animation()
        self.pose_names = [b.name for b in self.rig.pose.bones]

    # ---- clip sampling ----------------------------------------------------------------------------
    def _anim_datas(self):
        ads = [self.rig.animation_data]
        ads += [m.data.shape_keys.animation_data for m in self.meshes
                if m.data.shape_keys and m.data.shape_keys.animation_data]
        return ads

    def _sample_clip(self, clip):
        """Every whole frame of `clip`: [(bones, keys)] with bones = {name: (loc, quat, scale)} and
        keys = {(mesh, key): value}. All clips in v005 are closed loops (first frame == last frame)."""
        for ad in self._anim_datas():
            ad.action = None
            for tr in ad.nla_tracks:
                tr.mute = tr.name != clip
        strip = self.rig.animation_data.nla_tracks[clip].strips[0]
        f0, f1 = int(round(strip.frame_start)), int(round(strip.frame_end))
        out = []
        for f in range(f0, f1 + 1):
            self.S.frame_set(f)
            bpy.context.view_layer.update()
            bones = {b.name: (b.location.copy(), b.rotation_quaternion.copy(), b.scale.copy())
                     for b in self.rig.pose.bones}
            keys = {}
            for m in self.meshes:
                sk = m.data.shape_keys
                if sk:
                    for kb in sk.key_blocks:
                        keys[(m.name, kb.name)] = kb.value
            out.append((bones, keys))
        return out

    def _drop_animation(self):
        for ad in self._anim_datas():
            for tr in list(ad.nla_tracks):
                ad.nla_tracks.remove(tr)
        for m in self.meshes:
            if m.data.shape_keys:
                m.data.shape_keys.animation_data_clear()
        self.rig.animation_data_clear()
        for b in self.rig.pose.bones:
            b.rotation_mode = 'QUATERNION'

    def clip_at(self, clip, t):
        """Clip evaluated at `t` seconds, wrapped (closed loop), linear between whole frames."""
        frames = self.clips[clip]
        n = len(frames) - 1
        x = (t * FPS) % n
        i = int(math.floor(x))
        fr = x - i
        (b0, k0), (b1, k1) = frames[i], frames[i + 1]
        bones = {}
        for name, (l0, q0, s0) in b0.items():
            l1, q1, s1 = b1[name]
            if q0.dot(q1) < 0:
                q1 = -q1
            q = Quaternion((q0[0] + (q1[0] - q0[0]) * fr, q0[1] + (q1[1] - q0[1]) * fr,
                            q0[2] + (q1[2] - q0[2]) * fr, q0[3] + (q1[3] - q0[3]) * fr))
            q.normalize()
            bones[name] = (l0.lerp(l1, fr), q, s0.lerp(s1, fr))
        keys = {k: v + (k1[k] - v) * fr for k, v in k0.items()}
        return bones, keys

    def reset_pose(self, mix):
        """Write the blend of clip samples into the rig. `mix` = [(clip, seconds, weight), ...].
        Quaternions are blended with a normalised lerp (angles between two clips are small)."""
        tot = sum(w for _, _, w in mix)
        samples = [(self.clip_at(c, t), w / tot) for c, t, w in mix]
        for name in self.pose_names:
            pb = self.rig.pose.bones[name]
            loc, scl = Vector((0, 0, 0)), Vector((0, 0, 0))
            qa = [0.0, 0.0, 0.0, 0.0]
            ref = samples[0][0][0][name][1]
            for (bones, _), w in samples:
                l, q, s = bones[name]
                if ref.dot(q) < 0:
                    q = -q
                loc += l * w
                scl += s * w
                for i in range(4):
                    qa[i] += q[i] * w
            quat = Quaternion(qa)
            quat.normalize()
            pb.location, pb.rotation_quaternion, pb.scale = loc, quat, scl
        for m in self.meshes:
            sk = m.data.shape_keys
            if not sk:
                continue
            for kb in sk.key_blocks:
                if kb.name in BLINK_KEYS:
                    kb.value = 0.0
                else:
                    kb.value = sum(keys.get((m.name, kb.name), 0.0) * w for (_, keys), w in samples)
        self.update()

    def copy_bones(self, clip, t, names):
        """Overwrite some bones with `clip` at `t` seconds (after reset_pose). Used to keep a limb on the
        idle clip while the rest of the body takes a blend that moves it somewhere unwanted."""
        bones, _ = self.clip_at(clip, t)
        for n in names:
            pb = self.rig.pose.bones[n]
            pb.location, pb.rotation_quaternion, pb.scale = bones[n]
        self.update()

    # ---- helpers on top of Stage --------------------------------------------------------------------
    def add_morph(self, name, value):
        """Add to a shape key instead of replacing it, so the clip's own blinks and brow motion survive."""
        for m in self.meshes:
            sk = m.data.shape_keys
            if sk and name in sk.key_blocks:
                kb = sk.key_blocks[name]
                kb.value = max(0.0, min(1.0, kb.value + value))

    def translate_world(self, name, vec):
        self._apply_world(name, Matrix.Translation(Vector(vec)))

    def arm_to(self, side, w, target, pole, hand_dir):
        """Blend an arm from the pose it has now (the clip's) to an IK pose by weight `w` in 0..1.
        At w = 0 the target is the current hand position and the pole the current elbow, so the IK
        reproduces the clip arm instead of snapping to a default; at w = 1 it is the plain still-pose IK.
        Blending the IK inputs rather than the bone rotations avoids the elbow flipping through the
        two-bone solution's mirror branch half way.
        The elbow swings out first and the hand moves sideways ahead of its height: a straight lerp
        takes the hand up the front of the chest like a salute to herself."""
        if w <= 1e-4:
            return
        up, fore, hand = f'DEF-upper_arm.{side}', f'DEF-forearm.{side}', f'DEF-hand.{side}'
        h0, e0 = self.head_w(hand), self.head_w(fore)
        tgt = Vector(target)
        wx = smoothstep(0.0, 0.6, w)
        wp = smoothstep(0.0, 0.45, w)
        goal = Vector((lerp(h0.x, tgt.x, wx), lerp(h0.y, tgt.y, wx), lerp(h0.z, tgt.z, w)))
        self.arm_ik(side, goal, e0.lerp(Vector(pole), wp))
        d_now = (self.head_w(f'SOCKET-hand.{side}') - self.head_w(hand)).normalized()
        self.hand_point(side, d_now.lerp(Vector(hand_dir).normalized(), w))

    def socket_pos(self, side):
        return self.socket(side).to_translation()

    def reach_socket(self, side, goal, pole, hand_dir, iters=4):
        """Put the glove's SOCKET (where a prop sits) on the world point `goal`. arm_ik targets the wrist,
        which is 3 cm from the socket along the palm, so the wrist target is corrected a few times."""
        g = Vector(goal)
        d = Vector(hand_dir).normalized()
        t = g - d * 0.03
        for _ in range(iters):
            self.arm_ik(side, t, pole)
            self.hand_point(side, d)
            err = g - self.socket_pos(side)
            t = t + err
        self.arm_ik(side, t, pole)
        self.hand_point(side, d)
        return t


def smoothstep(a, b, x):
    if b == a:
        return 1.0 if x >= b else 0.0
    t = max(0.0, min(1.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)


def lerp(a, b, t):
    return a + (b - a) * t


def tri(p, c, half_w):
    """Raised-cosine bump of unit height centred on phase c (wrapping), full width 2 * half_w."""
    d = abs(((p - c + 0.5) % 1.0) - 0.5)
    if d >= half_w:
        return 0.0
    return 0.5 * (1 + math.cos(math.pi * d / half_w))
