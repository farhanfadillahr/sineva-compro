"""Contact sheet of PNG frames composited over a flat colour (default #EAF6F6).

  python3 -I scripts/loops/montage.py <frames_dir> <out.png> [--every 6] [--cols 6] [--px 300] [--bg EAF6F6]
                                      [--crop x:y:w:h]   crop each frame first (source pixels), then scale to --px

Frames are taken in file-name order, keeping index 0, n, 2n ... Uses ffmpeg only (xstack), no Pillow."""
import glob
import subprocess
import sys

a = sys.argv[1:]
src, out = a[0], a[1]
opt = lambda k, d: a[a.index(k) + 1] if k in a else d
crop = opt('--crop', None)
if crop:  # x:y:w:h -> ffmpeg's w:h:x:y
    x, y, w, h = crop.split(':')
    crop = f'{w}:{h}:{x}:{y}'
every, cols, px, bg = int(opt('--every', 1)), int(opt('--cols', 6)), int(opt('--px', 300)), opt('--bg', 'EAF6F6')
files = sorted(glob.glob(f'{src}/[0-9]*.png'))[::every]
rows = -(-len(files) // cols)
cmd = ['ffmpeg', '-y', '-loglevel', 'error']
for f in files:
    cmd += ['-i', f]
parts, labels = [], []
for i in range(len(files)):
    parts.append(f'color=c=0x{bg}:s={px}x{px}[b{i}];[{i}:v]{'crop=' + crop + ',' if crop else ''}scale={px}:{px},format=rgba[f{i}];[b{i}][f{i}]overlay=format=auto,format=rgb24[t{i}]')
    labels.append(f'[t{i}]')
layout = '|'.join(f'{(i % cols) * px}_{(i // cols) * px}' for i in range(len(files)))
parts.append(f'{"".join(labels)}xstack=inputs={len(files)}:layout={layout}:fill=0x{bg}')
cmd += ['-filter_complex', ';'.join(parts), '-frames:v', '1', out]
subprocess.run(cmd, check=True)
