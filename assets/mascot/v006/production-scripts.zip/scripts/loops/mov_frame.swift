// Decode one frame of an HEVC-with-alpha .mov through AVFoundation (ffmpeg's hevc decoder drops the alpha
// layer) and composite it over a flat colour, to check the Safari file for fringes.
//   swiftc -O mov_frame.swift -o /tmp/mov_frame
//   /tmp/mov_frame <file.mov> <frame_index> <bg RRGGBB> <out.rgb>      writes raw rgb24, prints size + alpha stats
import AVFoundation
import Foundation

let a = CommandLine.arguments
guard a.count == 5 else { print("usage: mov_frame file.mov frame bgRRGGBB out.rgb"); exit(2) }
let asset = AVURLAsset(url: URL(fileURLWithPath: a[1]))
let want = Int(a[2])!
let bg = UInt32(a[3], radix: 16)!
let br = Double((bg >> 16) & 255), bgG = Double((bg >> 8) & 255), bb = Double(bg & 255)
let sem = DispatchSemaphore(value: 0)
var track: AVAssetTrack!
Task { track = try! await asset.loadTracks(withMediaType: .video).first; sem.signal() }
sem.wait()
let reader = try! AVAssetReader(asset: asset)
let out = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
reader.add(out)
reader.startReading()
var i = 0
while let sb = out.copyNextSampleBuffer() {
    if i == want, let pb = CMSampleBufferGetImageBuffer(sb) {
        CVPixelBufferLockBaseAddress(pb, .readOnly)
        let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb), bpr = CVPixelBufferGetBytesPerRow(pb)
        let p = CVPixelBufferGetBaseAddress(pb)!.assumingMemoryBound(to: UInt8.self)
        var rgb = [UInt8](repeating: 0, count: w * h * 3)
        var transparent = 0, partial = 0, opaque = 0
        for y in 0..<h { for x in 0..<w {
            let o = y * bpr + x * 4
            let al = Double(p[o + 3]) / 255.0
            // AVFoundation hands back premultiplied BGRA: out = c + bg * (1 - a)
            rgb[(y * w + x) * 3 + 0] = UInt8(min(255, Double(p[o + 2]) + br * (1 - al)))
            rgb[(y * w + x) * 3 + 1] = UInt8(min(255, Double(p[o + 1]) + bgG * (1 - al)))
            rgb[(y * w + x) * 3 + 2] = UInt8(min(255, Double(p[o + 0]) + bb * (1 - al)))
            if p[o + 3] == 0 { transparent += 1 } else if p[o + 3] == 255 { opaque += 1 } else { partial += 1 }
        } }
        print("alpha mode attachment:", CVBufferCopyAttachment(pb, kCVImageBufferAlphaChannelModeKey, nil) as Any)
        for (px, py) in [(370, 650), (450, 640), (300, 300), (360, 200), (100, 100)] { let o = py * bpr + px * 4; print("px", px, py, "BGRA", p[o], p[o + 1], p[o + 2], p[o + 3]) }
        FileManager.default.createFile(atPath: a[4], contents: Data(rgb))
        print("\(w)x\(h) frame \(i) alpha: transparent \(transparent) partial \(partial) opaque \(opaque)")
        exit(0)
    }
    i += 1
}
print("frame \(want) not found (read \(i) frames)")
exit(1)
