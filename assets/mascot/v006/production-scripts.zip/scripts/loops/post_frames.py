"""Raw Cycles frames -> final loop frames: baked contact shadow + edge-colour bleed.

  python3 -I scripts/loops/post_frames.py <loop-id> [--out DIR]

Plain Python 3 with numpy (no Pillow here; PNG in and out goes through ffmpeg).
Reads   <out>/<id>/raw/NNNN.png, shadow_src.png, meta.json   (render_loops.py)
Writes  <out>/<id>/NNNN.png                                  RGBA, straight alpha

Same shadow recipe as scripts/web_assets/build_web.py (same colour, strength, gaussian pool sizes at
1200 px, scaled to the frame size) so a loop sits on the page exactly like its still pose. The shadow is
derived once, from frame 0, and reused for every frame (a feet-on-the-floor shadow does not move); only
the hop of L-thumbs lightens it while she is in the air.

The bleed matters for the video encoders: Cycles writes black RGB under fully transparent pixels, and
VP9 / HEVC blend colour across 2x2 chroma blocks and larger transform blocks, so that black leaks into the
silhouette edge as a dark fringe on a light page. Spreading the edge colour outwards removes it.
"""
import json
import os
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor

import numpy as np

BASE = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot/export/loops'
SHADOW_RGB = np.array([8, 63, 76], dtype=np.float32) / 255.0
SHADOW_STRENGTH = 0.5
SHADOW_SIGMA = {'default': (175, 60), 'L-build': (240, 80)}   # px at 1200, as build_web.SHADOW_SIGMA
BLEED_ITERS = 14
HOP_MAX = 0.04               # Thumbs.HOP in render_loops.py


def probe(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height',
                          '-of', 'csv=p=0', path], capture_output=True, text=True, check=True).stdout.strip()
    w, h = out.split(',')
    return int(w), int(h)


def load(path):
    w, h = probe(path)
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-f', 'rawvideo', '-pix_fmt', 'rgba', '-'],
                         capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.uint8).reshape(h, w, 4).astype(np.float32) / 255.0


def save(arr, path):
    h, w = arr.shape[:2]
    data = np.clip(arr * 255 + 0.5, 0, 255).astype(np.uint8).tobytes()
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', f'{w}x{h}', '-i', '-',
                    '-frames:v', '1', path], input=data, check=True)


def shadow_layer(plain, with_shadow, loop_id):
    """Alpha gained when the shadow catcher is on, times a gaussian pool centred on its dark core."""
    s = np.clip(with_shadow[..., 3] - plain[..., 3], 0, 1)
    if s.max() <= 0:
        return s
    ys, xs = np.nonzero(s > 0.6 * s.max())
    w = s[ys, xs]
    cx, cy = (xs * w).sum() / w.sum(), (ys * w).sum() / w.sum()
    sx, sy = SHADOW_SIGMA.get(loop_id, SHADOW_SIGMA['default'])
    yy, xx = np.mgrid[0:s.shape[0], 0:s.shape[1]].astype(np.float32)
    k = s.shape[1] / 1200.0
    pool = np.exp(-(((xx - cx) / (sx * k)) ** 2 + ((yy - cy) / (sy * k)) ** 2) / 2)
    return s * pool


def over(fg, bg):
    fa, ba = fg[..., 3:4], bg[..., 3:4]
    oa = fa + ba * (1 - fa)
    rgb = np.where(oa > 1e-6, (fg[..., :3] * fa + bg[..., :3] * ba * (1 - fa)) / np.maximum(oa, 1e-6), 0)
    return np.concatenate([rgb, oa], axis=-1)


def bleed(arr, iterations=BLEED_ITERS):
    """Spread colour from pixels that have alpha into the transparent ones around them (8-neighbour mean)."""
    rgb = arr[..., :3].copy()
    known = arr[..., 3] > 0.02
    H, W = known.shape
    for _ in range(iterations):
        pad = np.pad(rgb, ((1, 1), (1, 1), (0, 0)), mode='edge')
        kpad = np.pad(known, 1)
        acc = np.zeros_like(rgb)
        cnt = np.zeros(known.shape, np.float32)
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                k = kpad[1 + dy:1 + dy + H, 1 + dx:1 + dx + W]
                acc += pad[1 + dy:1 + dy + H, 1 + dx:1 + dx + W] * k[..., None]
                cnt += k
        fill = (~known) & (cnt > 0)
        rgb[fill] = acc[fill] / cnt[fill][:, None]
        known = known | fill
    out = arr.copy()
    out[..., :3] = np.where((arr[..., 3] <= 0.02)[..., None], rgb, arr[..., :3])
    return out


def process(args):
    src, dst, shadow, k = args
    plain = load(src)
    sh = np.zeros_like(plain)
    sh[..., :3] = SHADOW_RGB
    sh[..., 3] = shadow * SHADOW_STRENGTH * k
    save(bleed(over(plain, sh)), dst)


def main():
    loop_id = sys.argv[1]
    base = sys.argv[sys.argv.index('--out') + 1] if '--out' in sys.argv else BASE
    d = os.path.join(base, loop_id)
    meta = json.load(open(os.path.join(d, 'meta.json')))
    frames = sorted(f for f in os.listdir(os.path.join(d, 'raw')) if f.endswith('.png'))
    plain0 = load(os.path.join(d, 'raw', frames[0]))
    shadow = shadow_layer(plain0, load(os.path.join(d, 'shadow_src.png')), loop_id)
    jobs = []
    for f in frames:
        hop = meta.get(str(int(f[:4])), {}).get('hop', 0.0)
        k = 1.0 - 0.35 * min(1.0, hop / HOP_MAX)   # lighter and softer-looking while she is in the air
        jobs.append((os.path.join(d, 'raw', f), os.path.join(d, f), shadow, k))
    with ProcessPoolExecutor(max_workers=6) as ex:
        list(ex.map(process, jobs))
    print('POST DONE', loop_id, len(jobs), 'frames', flush=True)


if __name__ == '__main__':
    main()
