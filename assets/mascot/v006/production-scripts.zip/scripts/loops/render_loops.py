"""Render the five Sino website loops (PNG RGBA sequences, Cycles, transparent) from the v005 GLB.

  Blender -b --python scripts/loops/render_loops.py -- --loop L-wave [--frames 0,6,12 | --every 6]
                                                      [--size 720] [--samples 64] [--out DIR] [--preview]

One loop per Blender process (Stage resets the whole scene). tools:
  scripts/loops/post_frames.py   adds the contact shadow, bleeds edge colour, writes the final frames
  scripts/loops/encode_loops.py  webm (VP9 alpha) + mov (HEVC alpha) + poster

Look and framing are the still-pose pipeline's (scripts/web_assets): same GLB, same studio lights, AgX
Medium Contrast, exposure -0.4, same camera azimuth / target / half-height as the matching still. Every loop
is 72 frames at 24 fps (3.0 s) and a pure function of the phase p = frame / 72, built from clip samples
(see loop_stage.py), so frame 72 == frame 0 by construction and the loop is seamless.

Output per loop:  <out>/<id>/raw/NNNN.png        character only, straight alpha, what Cycles wrote
                  <out>/<id>/shadow_src.png      frame 0 with the shadow catcher on (post_frames.py derives the shadow)
                  <out>/<id>/meta.json           per-frame values post_frames.py needs (hop height)

Character space (as in the stills): +X is Sino's left, -Y is her front, +Z up, metres. Her arms are short
(shoulder to wrist ~19 cm), so reaches are small and every IK goal is checked against that.
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'web_assets'))  # props.py, sino_stage.py

import bpy
from mathutils import Euler, Matrix, Quaternion, Vector

import props as P
from loop_stage import LoopStage, lerp, smoothstep, tri
from sino_stage import cli_args

BASE = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot'
OUT_DEFAULT = f'{BASE}/export/loops'
N_FRAMES = 72
TAU = 2 * math.pi


def V(*a):
    return Vector(a)


def cam_gaze(az_deg):
    """World point 2.6 m out along the camera direction at eye height (as Stage.face_camera aims the eyes)."""
    a = math.radians(az_deg)
    return Vector((math.sin(a), -math.cos(a), 0.78)) * 2.6


def breathe(st, p, deg=1.1):
    """Chest rise and fall, one cycle per loop. The v005 idle clip only animates head, antenna and eyes,
    so without this the torso is dead still."""
    st.rotate_world('DEF-spine.002', (1, 0, 0), -deg * math.sin(TAU * p))
    st.rotate_world('DEF-chest', (1, 0, 0), -0.5 * deg * math.sin(TAU * p - 0.6))


BLINK = (0.45, 1.0, 0.7, 0.25)   # lid closure on four consecutive frames, shaped like the clips' own blink


def blink(st, p, frame):
    """One blink starting at loop frame `frame - 1`, fully closed on `frame`. The clips each carry a blink at a
    different time and a blend would play them at partial strength, so LoopStage drops theirs and the loops
    place this one. It is deliberately only 4 frames: at a fully closed lid the cornea shell shows through as a
    pale disc (known v005 issue), which is invisible for one frame and obvious if the blink is held."""
    k = round(p * N_FRAMES) - (frame - 1)
    if 0 <= k < len(BLINK):
        st.add_morph('eyeBlinkLeft', BLINK[k])
        st.add_morph('eyeBlinkRight', BLINK[k])


# ---- loops --------------------------------------------------------------------------------------------

class Wave:
    """greet_wave blended into idle. The arm rises beside the helmet (as in sino-wave), the hand sways three
    times, then the arm relaxes to idle and rises again for the loop. Frame 0 is the raised-arm key pose."""
    id = 'L-wave'
    still = 'sino-wave'
    clips = ['idle', 'greet_wave']
    az = -35
    cfg = {}

    def setup(self, st):
        return {}

    def pose(self, st, ctx, p):
        d = min(p, 1 - p)
        W = 1 - smoothstep(0.27, 0.42, d)            # 1 = arm up, 0 = idle arm
        g = ((p + 0.5) % 1.0) * 2.0                  # greet_wave time: p = 0 -> 1.0 s = clip peak
        st.reset_pose([('idle', p * 4.0, 1 - W + 1e-4), ('greet_wave', g, W)])
        # greet_wave swings the whole right arm across the chest on its way up; the raise is done by the IK
        # below (the clip only reaches hip height anyway), so the arm starts from the plain idle arm.
        st.copy_bones('idle', p * 4.0, ['DEF-upper_arm.R', 'DEF-forearm.R', 'DEF-hand.R'])
        st.arm_ik('R', V(-0.22, -0.02, 0.34), V(-0.4, -0.1, 0.4))
        breathe(st, p)
        s = math.sin(TAU * 6 * p) * W * W            # 6 swings per loop, about 3 inside the raised window
        st.rotate_world('DEF-spine.001', (0, 1, 0), 2.5 * W * math.sin(TAU * p + 0.4))
        st.arm_to('R', W, V(-0.29 + 0.012 * s, -0.12, 0.57 + 0.004 * abs(s)), V(-0.45, -0.20, 0.35),
                  V(-0.55 + 0.20 * s, -0.25, 1))
        st.rotate_world('DEF-head', (0, 0, 1), -35 * 0.55)
        st.rotate_world('DEF-head', (0, 1, 0), 3.5 * s)   # head tilts with the wave
        st.look_at(cam_gaze(-35))
        st.add_morph('browInnerUp', 0.25 * W)
        for k in ('mouthSmileLeft', 'mouthSmileRight'):
            st.add_morph(k, 0.40 + 0.2 * W)
        blink(st, p, 43)
        return {}


class Phone:
    """Holds the phone up (sino-holding-phone), eyes on the screen; a glance up at the viewer, then one small
    nod at the screen. The arm stays raised the whole loop."""
    id = 'L-phone'
    still = 'sino-holding-phone'
    clips = ['idle_b']
    az = 35
    cfg = {}

    def setup(self, st):
        ctx = {}
        self.pose(st, ctx, 0.0)
        ctx['phone'] = st.hold(P.phone(), 'L', grip_local=(0.0, 0.0, -0.015), rot_deg=(-12, 0, 38), scale=1.25)
        return ctx

    def pose(self, st, ctx, p):
        st.reset_pose([('idle_b', p * 4.0, 1.0)])
        st.copy_bones('idle_b', 0.0, ['DEF-upper_arm.R', 'DEF-forearm.R', 'DEF-hand.R'])
        st.arm_ik('R', V(-0.22, -0.02, 0.34), V(-0.4, -0.10, 0.40))
        breathe(st, p, 0.9)
        glance = tri(p, 0.36, 0.13)                  # 1 = looking at the viewer
        nod = tri(p, 0.74, 0.11)
        st.arm_ik('L', V(0.21, -0.16, 0.44 + 0.004 * math.sin(TAU * p)), V(0.4, 0.1, 0.30))
        st.hand_point('L', V(0.0, -0.5, 1.0))
        st.curl('L', deg=35)
        st.rotate_world('DEF-head', (0, 0, 1), lerp(22, 17, glance))
        st.rotate_world('DEF-head', (1, 0, 0), lerp(6, -3, glance) + 9 * nod)
        st.look_at(Vector(V(0.24, -0.22, 0.54)).lerp(cam_gaze(35), glance))
        for k in ('mouthSmileLeft', 'mouthSmileRight'):
            st.add_morph(k, 0.35 + 0.3 * glance + 0.1 * nod)
        st.add_morph('browInnerUp', 0.18 * glance)
        blink(st, p, 11)
        return {}


class Build:
    """Block in the left hand: lowers it onto the tower, lets go, the hand lifts away and comes back, picks
    it up again and raises it to the hover pose. The block is never on the tower at frame 0 / 72, so the loop
    needs the pick-up; the alternative (a third block appearing) would pop."""
    id = 'L-build'
    still = 'sino-blocks'
    clips = ['idle']
    az = 35
    cfg = dict(target=(0.12, 0, 0.50), half=0.74)
    PLACE = V(0.206, -0.197, 0.425)       # centre of a block resting on the 2-block tower (top at z 0.48)
    POLE = V(0.45, -0.30, 0.3)
    HAND_DIR = V(0.0, -0.4, -1)

    def setup(self, st):
        ctx = {}
        P.place(P.desk(width=0.50, depth=0.26, height=0.25), (0.09, -0.22, 0.0))
        P.place(P.blocks_stack(), (0.20, -0.20, 0.25))
        blk = P.block_single('teal500')
        ctx['block'] = blk
        # hover pose = the sino-blocks still: same lean, same wrist target, socket read off the result
        st.reset_pose([('idle', 0.0, 1.0)])
        for b, d in (('DEF-spine.001', 4), ('DEF-spine.002', 2)):
            st.rotate_world(b, (1, 0, 0), d)
        st.arm_ik('L', V(0.22, -0.18, 0.49), self.POLE)
        st.hand_point('L', self.HAND_DIR)
        ctx['hover'] = st.socket_pos('L')
        # block orientation relative to the socket at the reference pose (a free object driven by hand
        # every frame, not bone-parented: it has to let go of the hand and sit on the tower)
        sock0 = st.socket('L')
        R0 = Euler([math.radians(a) for a in (0, 0, 10)], 'XYZ').to_quaternion()
        ctx['off_rot'] = sock0.to_quaternion().inverted() @ R0
        ctx['flat'] = R0
        ctx['placed_q'] = R0
        return ctx

    # keyframes (phase, goal key). Eased between neighbours.
    def goal(self, ctx, p):
        H, PL = ctx['hover'], self.PLACE
        away = PL + V(0.03, -0.02, 0.04)
        keys = [(0.00, H), (0.08, H), (0.36, PL), (0.46, PL), (0.55, away), (0.63, away), (0.74, PL),
                (0.80, PL), (0.93, H), (1.00, H)]
        for (a, ga), (b, gb) in zip(keys, keys[1:]):
            if a <= p <= b:
                return ga.lerp(gb, smoothstep(a, b, p))
        return H

    def pose(self, st, ctx, p):
        st.reset_pose([('idle', p * 4.0, 1.0)])
        breathe(st, p, 0.8)
        down = smoothstep(0.08, 0.36, p) - smoothstep(0.80, 0.93, p)   # 1 while the block is at the tower
        for b, d in (('DEF-spine.001', 4 + 3 * down), ('DEF-spine.002', 2 + 2 * down)):
            st.rotate_world(b, (1, 0, 0), d)
        st.reach_socket('L', self.goal(ctx, p), self.POLE, self.HAND_DIR)
        release = smoothstep(0.38, 0.46, p) - smoothstep(0.70, 0.78, p)   # 1 = fingers open, block let go
        st.curl('L', deg=lerp(30, 6, release))
        st.arm_ik('R', V(-0.08, -0.14, 0.43), V(-0.3, 0.0, 0.3))
        st.rotate_world('DEF-head', (1, 0, 0), 6 + 5 * down)
        st.rotate_world('DEF-head', (0, 0, 1), 14)
        st.look_at(st.socket_pos('L').lerp(self.PLACE, down) if release < 0.5 else self.PLACE)
        for k in ('mouthSmileLeft', 'mouthSmileRight'):
            st.add_morph(k, 0.4 + 0.3 * tri(p, 0.52, 0.12))
        blink(st, p, 20)
        # block: in the hand, or sitting on the tower while the fingers are open
        blk = ctx['block']
        in_hand = not (0.42 <= p <= 0.74)
        pos = st.socket_pos('L') if in_hand else self.PLACE
        q_att = st.socket('L').to_quaternion() @ ctx['off_rot']
        flat_w = smoothstep(0.20, 0.36, p) - smoothstep(0.80, 0.93, p)
        q = q_att.slerp(ctx['flat'], flat_w) if in_hand else ctx['flat']
        blk.matrix_world = Matrix.Translation(pos) @ q.to_matrix().to_4x4()
        err = (st.socket_pos('L') - self.goal(ctx, p)).length
        return {'reach_err': err}


class Thumbs:
    """happy_success twice per loop, a small hop on each beat, right arm up with the thumb out (sino-thumbs-up)."""
    id = 'L-thumbs'
    still = 'sino-thumbs-up'
    clips = ['happy_success']
    az = -35
    cfg = {}
    HOP = 0.04

    def setup(self, st):
        return {}

    def pose(self, st, ctx, p):
        st.reset_pose([('happy_success', p * 3.0, 1.0)])   # 1.5 s clip, two beats in 3 s
        u = (p * 2) % 1.0
        hop = self.HOP * 4 * u * (1 - u)                    # parabola, feet back on the floor at p = 0
        hn = hop / self.HOP
        st.translate_world('DEF-root', (0, 0, hop))
        breathe(st, p, 0.8)
        st.rotate_world('DEF-spine.001', (1, 0, 0), -2.5 * hn)
        pump = 0.5 + 0.5 * math.sin(TAU * 2 * p - 0.9)
        st.arm_ik('R', V(-0.23, -0.12, 0.56 + hop + 0.014 * pump), V(-0.45, 0.05, 0.25 + hop))
        st.hand_point('R', V(-0.35, -1.0, 0.0))
        st.roll_thumb_to('R', (0, 0, 1))
        st.curl('R', deg=80)
        st.rotate_world('DEF-upper_arm.L', (0, 1, 0), -9 * hn)   # free arm swings out on the hop
        st.rotate_world('DEF-head', (0, 0, 1), -35 * 0.55)
        st.rotate_world('DEF-head', (1, 0, 0), 3.0 * math.sin(TAU * 2 * p - 0.5))
        st.look_at(cam_gaze(-35))
        st.add_morph('blink_happy', 0.4 + 0.2 * hn)
        for k in ('mouthSmileLeft', 'mouthSmileRight'):
            st.add_morph(k, 0.8)
        st.add_morph('jawOpen', 0.10 + 0.08 * hn)
        blink(st, p, 58)
        return {'hop': hop}


class Confused:
    """Left hand scratches the helmet (sino-confused), then she looks left, then right, with the hand
    resting by the helmet, then back to scratching."""
    id = 'L-confused'
    still = 'sino-confused'
    clips = ['thinking']
    az = 35
    cfg = {}

    def setup(self, st):
        return {}

    def pose(self, st, ctx, p):
        st.reset_pose([('thinking', p * 2.0, 1.0)])
        st.arm_ik('R', V(-0.22, -0.02, 0.34), V(-0.4, -0.10, 0.40))
        breathe(st, p, 0.9)
        S = 1 - smoothstep(0.40, 0.52, p) + smoothstep(0.88, 1.0, p)   # scratching amount
        scr = math.sin(TAU * 4 * p)                                     # four strokes per loop
        scr2 = math.sin(TAU * 4 * p + 1.3)
        rest = V(0.29, -0.10, 0.60)   # on the helmet's lower side; the arm is 19 cm, higher is out of reach
        stroke = V(0.01 * scr2, 0.025 * scr, 0.012 * scr2) * S
        st.arm_ik('L', rest + stroke, V(0.45, -0.30, 0.3))
        st.hand_point('L', V(0.3 + 0.35 * scr * S, 0.0, 1.0))
        st.curl('L', deg=40)
        # head: tilt towards the hand (kept), yaw swings left then right during the look-around
        look = -20 * tri(p, 0.62, 0.11) + 18 * tri(p, 0.80, 0.09)
        st.rotate_world('DEF-head', (0, 1, 0), 11 - 4 * (1 - S))
        st.rotate_world('DEF-head', (0, 0, 1), 10 + look)
        eye_yaw = math.radians(10 + look + 14 * (1 if look > 0 else -1) * min(1.0, abs(look) / 10))
        gaze = Vector((math.sin(eye_yaw), -math.cos(eye_yaw), 0.35)) * 2.0
        up_aside = V(0.3, -0.5, 1.2)
        st.look_at(Vector(up_aside).lerp(gaze, 1 - S))
        st.add_morph('browInnerUp', 0.7)
        st.add_morph('browDownRight', 0.5)
        st.add_morph('browOuterUpLeft', 0.5)
        st.add_morph('mouthFrownLeft', 0.5)
        st.add_morph('mouthFrownRight', 0.35)
        st.add_morph('mouthRight', 0.4)
        blink(st, p, 37)
        return {}


LOOPS = {c.id: c for c in (Wave, Phone, Build, Thumbs, Confused)}


# ---- driver --------------------------------------------------------------------------------------------

def parse_frames(a):
    if '--frames' in a:
        return [int(v) for v in a[a.index('--frames') + 1].split(',')]
    if '--every' in a:
        return list(range(0, N_FRAMES, int(a[a.index('--every') + 1])))
    return list(range(N_FRAMES))


def main():
    a = cli_args()
    lid = a[a.index('--loop') + 1]
    preview = '--preview' in a
    size = int(a[a.index('--size') + 1]) if '--size' in a else (360 if preview else 720)
    samples = int(a[a.index('--samples') + 1]) if '--samples' in a else (16 if preview else 64)
    out = a[a.index('--out') + 1] if '--out' in a else OUT_DEFAULT
    frames = parse_frames(a)
    loop = LOOPS[lid]()
    d = os.path.join(out, lid)
    os.makedirs(os.path.join(d, 'raw'), exist_ok=True)

    st = LoopStage(loop.clips)
    P._mats.clear()
    ctx = loop.setup(st)

    # same studio as render_poses.py
    st.studio(loop.az, shadow=True, exposure=-0.4)
    bpy.data.lights['fill'].energy = 70
    bpy.data.lights['top'].energy = 50
    bpy.data.worlds['studio-world'].node_tree.nodes['Background'].inputs[1].default_value = 0.3
    target = loop.cfg.get('target', (0, 0, 0.55))
    half = loop.cfg.get('half', 0.66)
    st.camera(loop.az, fov_deg=28.8, target=target, half=half)
    # the ground only exists for the shadow pass (Stage.render_pair); keep it out of the character frames
    st.ground.hide_render = True

    meta_path = os.path.join(d, 'meta.json')
    meta = json.load(open(meta_path)) if os.path.exists(meta_path) else {}
    import time
    for f in frames:
        t0 = time.time()
        info = loop.pose(st, ctx, f / N_FRAMES)
        t1 = time.time()
        st.render(os.path.join(d, 'raw', f'{f:04d}.png'), size, samples)
        meta[str(f)] = info
        print(f'FRAME {f} pose {t1 - t0:.1f}s render {time.time() - t1:.1f}s {info}', flush=True)
        json.dump(meta, open(meta_path, 'w'), indent=1)

    if not preview and '--no-shadow' not in a:
        # frame 0 again, now with the shadow catcher: post_frames.py turns (this alpha - raw/0000 alpha) into
        # the contact shadow, exactly like build_web.py does for the stills
        loop.pose(st, ctx, 0.0)
        for n in ('key', 'fill', 'rim', 'face'):
            bpy.data.objects[n].hide_render = True
        top = bpy.data.objects['top']
        top.data.energy = 420
        top.data.size = 1.4
        top.location = Vector((-0.25, -0.2, 2.6))
        top.rotation_euler = (Vector((0, 0, 0.3)) - top.location).to_track_quat('-Z', 'Y').to_euler()
        next(n for n in st.S.world.node_tree.nodes if n.type == 'BACKGROUND').inputs[1].default_value = 0.12
        st.ground.hide_render = False
        st.ground.is_shadow_catcher = True
        st.render(os.path.join(d, 'shadow_src.png'), size, 48)
    print('LOOP DONE', lid, flush=True)


main()
