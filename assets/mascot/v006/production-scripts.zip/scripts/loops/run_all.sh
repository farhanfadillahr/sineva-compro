#!/bin/zsh
# Render every loop (Cycles, 720 px) and post-process it. Usage: scripts/loops/run_all.sh [samples=128] [loop ids...]
B=/Applications/Blender.app/Contents/MacOS/Blender
D=${0:A:h}
samples=${1:-128}; shift
ids=(${@:-L-wave L-phone L-build L-thumbs L-confused})
for id in $ids; do
  rm -rf $D/../../export/loops/$id
  $B -b --python $D/render_loops.py -- --loop $id --size 720 --samples $samples 2>&1 | grep -E "FRAME (0|36|71) |LOOP DONE|Traceback|rror"
  python3 -I $D/post_frames.py $id
done
