from pathlib import Path
import sys,bpy,json
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D));sys.path.insert(0,str(D.parent/'loops'))
a={'__file__':str(D.parent/'loops/audit_collisions.py')}
exec(compile(Path(a['__file__']).read_text().split('\nout={}')[0],a['__file__'],'exec'),a)
ns={'__file__':str(D/'render_poses.py')}
exec(compile((D/'render_poses.py').read_text().rsplit('\nmain()',1)[0],ns['__file__'],'exec'),ns)
import sino_stage as SS
SS.GLB=str(D.parents[1]/'export/web/sino_v006.draco.glb')
rows={}
for name,fn in ns['POSES'].items():
 ns['P']._mats.clear();st,cfg=fn();bpy.context.view_layer.update();hits=a['audit'](st,hand_props=name=='sino-laptop');rows[name]=hits
 print('POSE_COLLISION',name,hits,flush=True)
Path('/tmp/sineva-pose-collisions.json').write_text(json.dumps(rows,indent=2))
