"""Turn the raw Blender renders into masters, web formats, the OG image and a contact sheet.

Plain Python 3 with Pillow and numpy (NOT Blender's Python):
  python3 -I scripts/web_assets/build_web.py [--public /path/to/site/public] [--sheet /path/sheet.png]
                                              [--logo /path/sineva-stacked-original.png]

Reads  export/renders/web_assets/raw/<name>.png and <name>_withshadow.png (render_poses.py)
Writes export/renders/web_assets/<name>.png          master, 1200 px (poster 1600), subtle baked shadow
       export/renders/web_assets/shadow/<name>_shadow.png   the shadow layer alone (straight alpha)
       export/renders/web_assets/web/<name>.webp|.avif      web formats
       export/renders/web_assets/og/default.png             1200x630 Open Graph image
Tools: cwebp (WebP), avifenc (AVIF). Both must be on PATH.
"""
import json
import os
import subprocess
import sys
import tempfile

import numpy as np
from PIL import Image, ImageFilter

BASE = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot/export/renders/web_assets'
RAW = f'{BASE}/raw'
POSES = ['sino-wave', 'sino-holding-phone', 'sino-laptop', 'sino-megaphone', 'sino-coins', 'sino-handshake',
         'sino-magnifier', 'sino-blocks', 'sino-whiteboard', 'sino-thumbs-up', 'sino-confused', 'sino-relaxed']
# ink-teal shadow colour (tokens.md contact shadow: rgba(8, 63, 76, .18) on the stage; the baked one is a
# little stronger because it has to hold on white without the CSS glow behind it)
SHADOW_RGB = np.array([8, 63, 76], dtype=np.float32)
SHADOW_STRENGTH = 0.5
# The rendered floor shadow is lit by one big overhead softbox, so it is long and diffuse. It is kept for
# its shape (feet, desk legs) but multiplied by a gaussian pool centred on its own dark core, sigma in px
# at 1200 px (about 0.2 m wide and 0.07 m deep on the floor), so it reads as a contact shadow and never
# touches the frame edge.
SHADOW_SIGMA = {'default': (175, 60), 'sino-laptop': (240, 80), 'sino-blocks': (240, 80), 'sino-whiteboard': (250, 80)}
WEBP_Q, AVIF_Q = 82, 70


def load(path):
    return np.asarray(Image.open(path).convert('RGBA'), dtype=np.float32) / 255.0


def save_rgba(arr, path):
    Image.fromarray(np.clip(arr * 255 + 0.5, 0, 255).astype(np.uint8), 'RGBA').save(path, optimize=True)


def shadow_layer(plain, with_shadow, name):
    """Shadow alpha = alpha gained when the shadow catcher is on. Inside the character both alphas are 1, so
    the difference is 0 there; it is only non-zero on the floor."""
    s = np.clip(with_shadow[..., 3] - plain[..., 3], 0, 1)
    if s.max() <= 0:
        return s
    ys, xs = np.nonzero(s > 0.6 * s.max())
    w = s[ys, xs]
    cx, cy = (xs * w).sum() / w.sum(), (ys * w).sum() / w.sum()
    sx, sy = SHADOW_SIGMA.get(name, SHADOW_SIGMA['default'])
    yy, xx = np.mgrid[0:s.shape[0], 0:s.shape[1]].astype(np.float32)
    k = s.shape[1] / 1200.0
    pool = np.exp(-(((xx - cx) / (sx * k)) ** 2 + ((yy - cy) / (sy * k)) ** 2) / 2)
    return s * pool


def over(fg, bg):
    """Straight-alpha 'over'."""
    fa, ba = fg[..., 3:4], bg[..., 3:4]
    oa = fa + ba * (1 - fa)
    rgb = np.where(oa > 1e-6, (fg[..., :3] * fa + bg[..., :3] * ba * (1 - fa)) / np.maximum(oa, 1e-6), 0)
    return np.concatenate([rgb, oa], axis=-1)


def bleed(arr, iterations=6):
    """Spread edge colour into the fully transparent pixels. Lossy encoders blend neighbouring colour
    across alpha edges; without this, whatever RGB sits under alpha 0 (black from the renderer) leaks into
    the edge pixels and shows as a dark fringe on light backgrounds."""
    rgb = arr[..., :3].copy()
    known = arr[..., 3] > 0.02
    for _ in range(iterations):
        pad = np.pad(rgb, ((1, 1), (1, 1), (0, 0)), mode='edge')
        kpad = np.pad(known, 1)
        acc = np.zeros_like(rgb)
        cnt = np.zeros(known.shape, np.float32)
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                k = kpad[1 + dy:1 + dy + known.shape[0], 1 + dx:1 + dx + known.shape[1]]
                acc += pad[1 + dy:1 + dy + known.shape[0], 1 + dx:1 + dx + known.shape[1]] * k[..., None]
                cnt += k
        fill = (~known) & (cnt > 0)
        rgb[fill] = acc[fill] / cnt[fill][:, None]
        known = known | fill
    out = arr.copy()
    out[..., :3] = np.where((arr[..., 3] <= 0.02)[..., None], rgb, arr[..., :3])
    return out


def make_master(name):
    plain = load(f'{RAW}/{name}.png')
    ws_path = f'{RAW}/{name}_withshadow.png'
    if os.path.exists(ws_path):
        s = shadow_layer(plain, load(ws_path), name)
        sh = np.zeros_like(plain)
        sh[..., :3] = SHADOW_RGB / 255.0
        sh[..., 3] = s
        os.makedirs(f'{BASE}/shadow', exist_ok=True)
        save_rgba(sh, f'{BASE}/shadow/{name}_shadow.png')
        sh[..., 3] = s * SHADOW_STRENGTH
        master = over(plain, sh)
    else:
        master = plain
    master = bleed(master)
    save_rgba(master, f'{BASE}/{name}.png')
    return master


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f'{cmd[0]} failed: {r.stderr}')


def encode(name, size_limit_kb):
    src = f'{BASE}/{name}.png'
    os.makedirs(f'{BASE}/web', exist_ok=True)
    webp, avif = f'{BASE}/web/{name}.webp', f'{BASE}/web/{name}.avif'
    # -alpha_q 90: the alpha channel carries the silhouette edge, keep it cleaner than the colour
    q = WEBP_Q
    while True:
        run(['cwebp', '-quiet', '-q', str(q), '-alpha_q', '90', '-m', '6', '-pass', '10', '-sharp_yuv', src, '-o', webp])
        if os.path.getsize(webp) <= size_limit_kb * 1000 or q <= 60:
            break
        q -= 3
    qa = AVIF_Q
    while True:
        run(['avifenc', '-q', str(qa), '--qalpha', '85', '-s', '4', '-j', 'all', '-y', '420', src, avif])
        if os.path.getsize(avif) <= size_limit_kb * 1000 or qa <= 35:
            break
        qa -= 4
    return webp, avif, q, qa


def decode_webp(path):
    with tempfile.TemporaryDirectory() as d:
        png = f'{d}/x.png'
        run(['dwebp', path, '-o', png])
        return load(png)


def decode_avif(path):
    with tempfile.TemporaryDirectory() as d:
        png = f'{d}/x.png'
        run(['avifdec', path, png])
        return load(png)


def composite(arr, hex_bg):
    bg = np.array([int(hex_bg[i:i + 2], 16) for i in (1, 3, 5)], dtype=np.float32) / 255.0
    return arr[..., :3] * arr[..., 3:4] + bg * (1 - arr[..., 3:4])


def fringe_report(master, decoded, hex_bg):
    """Dark fringe = edge pixels (0.02 < alpha < 0.98) that composite darker than both the background
    and the nearest solid sprite colour would explain. Measured as the mean luminance drop of the decoded
    edge pixels against the same pixels of the lossless master, plus the share of edge pixels more than
    6/255 darker than the master."""
    edge = (master[..., 3] > 0.02) & (master[..., 3] < 0.98)
    if edge.sum() == 0:
        return 0.0, 0.0
    lum = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)
    a = composite(master, hex_bg) @ lum
    b = composite(decoded, hex_bg) @ lum
    drop = (a - b)[edge]
    return float(drop.mean() * 255), float((drop > 6 / 255).mean())


def aurora(w, h):
    """tokens.md --gradient-aurora on #F5F8F8: three radial blobs, evaluated per pixel (CSS radial-gradient
    'ellipse' with the given radii, transparent at 70%)."""
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    base = np.array([0xF5, 0xF8, 0xF8], dtype=np.float32)
    out = np.tile(base, (h, w, 1))

    def blob(cx, cy, rx, ry, rgb, alpha):
        d = np.sqrt(((x - cx * w) / (rx * w)) ** 2 + ((y - cy * h) / (ry * h)) ** 2)
        t = np.clip(d / 0.7, 0, 1)
        a = (alpha * (1 - t))[..., None]
        return rgb * a, a
    for cx, cy, rx, ry, rgb, al in [
        (0.20, 0.0, 0.60, 0.50, np.array([47, 224, 216], np.float32), 0.18),
        (0.85, 0.10, 0.50, 0.45, np.array([0, 148, 155], np.float32), 0.14),
        (0.50, 1.0, 0.40, 0.40, np.array([255, 181, 71], np.float32), 0.10),
    ]:
        c, a = blob(cx, cy, rx, ry, rgb, al)
        out = out * (1 - a) + c
    return out


def make_og(logo_path, out_path):
    W, H = 1200, 630
    bg = aurora(W, H)
    canvas = Image.fromarray(np.clip(bg + 0.5, 0, 255).astype(np.uint8), 'RGB').convert('RGBA')
    sino = Image.open(f'{BASE}/sino-wave.png').convert('RGBA')
    s = 664
    sino = sino.resize((s, s), Image.LANCZOS)
    canvas.alpha_composite(sino, (W - s - 40, (H - s) // 2 + 10))
    logo = Image.open(logo_path).convert('RGBA')
    bbox = logo.getbbox()
    logo = logo.crop(bbox)
    lw = 380
    logo = logo.resize((lw, int(logo.height * lw / logo.width)), Image.LANCZOS)
    canvas.alpha_composite(logo, (110, (H - logo.height) // 2))
    # Truecolour PNG, no dithering noise: a smooth gradient compresses to well under the 300 KB budget,
    # while noise (needed to hide banding on large fields) doubles the size. The aurora alpha tops out at
    # .18, so each 8-bit band is about 20 px wide and not visible.
    canvas.convert('RGB').save(out_path, optimize=True)
    size = os.path.getsize(out_path)
    if size > 300_000:
        sys.exit(f'OG image is {size} bytes, over the 300 KB budget')
    return size, 'truecolour'


def contact_sheet(names, path, bg_hex='#FFFFFF', cell=400, cols=4):
    rows = (len(names) + cols - 1) // cols
    sheet = Image.new('RGB', (cell * cols, cell * rows), bg_hex)
    for i, n in enumerate(names):
        im = Image.open(f'{BASE}/{n}.png').convert('RGBA').resize((cell, cell), Image.LANCZOS)
        sheet.paste(im, ((i % cols) * cell, (i // cols) * cell), im)
    sheet.save(path)


def main():
    a = sys.argv[1:]
    public = a[a.index('--public') + 1] if '--public' in a else None
    sheet = a[a.index('--sheet') + 1] if '--sheet' in a else None
    logo = a[a.index('--logo') + 1] if '--logo' in a else None
    rows = []
    for name in POSES + ['sino-hero']:
        make_master(name)
        limit = 150 if name == 'sino-hero' else 120
        webp, avif, q, qa = encode(name, limit)
        master = load(f'{BASE}/{name}.png')
        res = {}
        for bg in ('#FFFFFF', '#EAF6F6'):
            res[bg] = {'webp': fringe_report(master, decode_webp(webp), bg), 'avif': fringe_report(master, decode_avif(avif), bg)}
        rows.append((name, master.shape[1], os.path.getsize(f'{BASE}/{name}.png'), os.path.getsize(webp), q,
                     os.path.getsize(avif), qa, res))
        print(f'{name:20s} {master.shape[1]}px png {rows[-1][2]/1000:7.0f}KB webp {rows[-1][3]/1000:6.1f}KB(q{q}) '
              f'avif {rows[-1][5]/1000:6.1f}KB(q{qa}) fringe(white,webp)={res["#FFFFFF"]["webp"][0]:.2f}/{res["#FFFFFF"]["webp"][1]*100:.2f}% '
              f'(tint,avif)={res["#EAF6F6"]["avif"][0]:.2f}/{res["#EAF6F6"]["avif"][1]*100:.2f}%', flush=True)
    if logo:
        os.makedirs(f'{BASE}/og', exist_ok=True)
        size, mode = make_og(logo, f'{BASE}/og/default.png')
        print(f'og/default.png 1200x630 {size/1000:.1f}KB ({mode})')
    if sheet:
        contact_sheet(POSES, sheet)
        contact_sheet(POSES, sheet.replace('.png', '_tint.png'), '#EAF6F6')
    if public:
        for sub, ext_list, names in (('mascot/poses', ('webp', 'avif'), POSES), ('mascot/poster', ('webp', 'avif'), ['sino-hero'])):
            os.makedirs(f'{public}/{sub}', exist_ok=True)
            for n in names:
                for ext in ext_list:
                    with open(f'{BASE}/web/{n}.{ext}', 'rb') as s, open(f'{public}/{sub}/{n}.{ext}', 'wb') as d:
                        d.write(s.read())
        if logo:
            os.makedirs(f'{public}/og', exist_ok=True)
            with open(f'{BASE}/og/default.png', 'rb') as s, open(f'{public}/og/default.png', 'wb') as d:
                d.write(s.read())
    with open(f'{BASE}/size_report.json', 'w') as f:
        json.dump([{'name': r[0], 'px': r[1], 'png': r[2], 'webp': r[3], 'webp_q': r[4], 'avif': r[5], 'avif_q': r[6]} for r in rows], f, indent=1)


if __name__ == '__main__':
    main()
