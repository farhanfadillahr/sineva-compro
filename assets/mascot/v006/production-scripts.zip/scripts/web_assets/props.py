"""Simple low-poly props for the pose stills, in the brand palette (teal / white / ink, sun-500 for
coins and the mug band only). Every builder returns one parent Empty named `PROP-<name>` with the
parts as children, modelled upright at the origin in metres (Sino is 1.09 m tall, her hands are about
6 cm wide, so props are deliberately small and chunky).

Style rules, so the set reads as one family: a bevel of about 1.5 mm on every hard edge, matte-soft
materials (roughness 0.4-0.55), no text, no logos, no real products. Screens carry abstract chat
bubbles and bars only, because product UI may only show features confirmed by the team.

Local axes: +Z up, the "front" of a prop (screen, mouth, face of the board) looks towards -Y.
"""
import math

import bpy
from mathutils import Euler, Vector

from sino_stage import material

_mats = {}


def mat(key, color, **kw):
    if key not in _mats or _mats[key].name not in bpy.data.materials:
        _mats[key] = material(f'PROP-{key}', color, **kw)
    return _mats[key]


def _finish(obj, material_, bevel=0.0015, smooth=True):
    obj.data.materials.clear()
    obj.data.materials.append(material_)
    if smooth:
        for p in obj.data.polygons:
            p.use_smooth = True
    if bevel:
        m = obj.modifiers.new('bevel', 'BEVEL')
        m.width = bevel
        m.segments = 3
        m.limit_method = 'ANGLE'
        m.angle_limit = math.radians(35)
    return obj


def box(name, size, loc, material_, parent=None, bevel=0.0015, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(scale=True)
    o.rotation_euler = Euler([math.radians(a) for a in rot])
    _finish(o, material_, bevel)
    if parent:
        o.parent = parent
    return o


def cyl(name, r, h, loc, material_, parent=None, rot=(0, 0, 0), r2=None, verts=32, bevel=0.001):
    """Cylinder / truncated cone (`r2` = radius of the +Z end)."""
    if r2 is None:
        bpy.ops.mesh.primitive_cylinder_add(radius=r, depth=h, location=loc, vertices=verts)
    else:
        bpy.ops.mesh.primitive_cone_add(radius1=r, radius2=r2, depth=h, location=loc, vertices=verts)
    o = bpy.context.active_object
    o.name = name
    o.rotation_euler = Euler([math.radians(a) for a in rot])
    _finish(o, material_, bevel)
    if parent:
        o.parent = parent
    return o


def sphere(name, r, loc, material_, parent=None):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=loc, segments=24, ring_count=16)
    o = bpy.context.active_object
    o.name = name
    _finish(o, material_, 0)
    if parent:
        o.parent = parent
    return o


def torus(name, major, minor, loc, material_, parent=None, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, location=loc,
                                     major_segments=40, minor_segments=12)
    o = bpy.context.active_object
    o.name = name
    o.rotation_euler = Euler([math.radians(a) for a in rot])
    _finish(o, material_, 0)
    if parent:
        o.parent = parent
    return o


def root(name):
    e = bpy.data.objects.new(f'PROP-{name}', None)
    bpy.context.scene.collection.objects.link(e)
    return e


# ---- individual props ---------------------------------------------------------------------------

def phone(with_screen=True):
    """Handheld phone, 8.4 x 16.5 cm (scaled for Sino's hands). Screen faces -Y."""
    r = root('phone')
    box('phone-body', (0.084, 0.012, 0.165), (0, 0, 0), mat('ink', 'ink950', roughness=0.35), r, bevel=0.004)
    if with_screen:
        box('phone-screen', (0.076, 0.002, 0.152), (0, -0.0062, 0), mat('screen', 'teal100', roughness=0.25, emission='teal100'), r, bevel=0.002)
        # abstract chat bubbles: incoming (white, left), outgoing (teal, right), no text
        for i, (w, x, color, z) in enumerate([(0.040, -0.012, 'white', 0.046), (0.034, 0.014, 'teal500', 0.018),
                                              (0.046, -0.008, 'white', -0.010), (0.028, 0.019, 'teal500', -0.036)]):
            box(f'bubble{i}', (w, 0.0016, 0.016), (x, -0.0078, z), mat(f'b-{color}', color, roughness=0.5), r, bevel=0.0006)
        box('phone-notch', (0.022, 0.0016, 0.004), (0, -0.0078, 0.071), mat('ink', 'ink950'), r, bevel=0.0006)
    return r


def laptop(open_deg=108):
    """Small laptop, 26 x 18 cm closed footprint. Keyboard deck on z=0..0.012, lid hinged at the back (+Y);
    the screen looks towards -Y when the laptop's user would sit at -Y."""
    r = root('laptop')
    box('deck', (0.26, 0.18, 0.012), (0, 0, 0.006), mat('white', 'white', roughness=0.4), r, bevel=0.003)
    box('keys', (0.22, 0.10, 0.003), (0, -0.012, 0.0135), mat('keys', 'teal100', roughness=0.5), r, bevel=0.0008)
    box('trackpad', (0.07, 0.04, 0.002), (0, -0.068, 0.0125), mat('white2', '#E4EEEE', roughness=0.5), r, bevel=0.0006)
    lid = root('lid')
    lid.parent = r
    lid.location = (0, 0.09, 0.012)
    lid.rotation_euler = (math.radians(open_deg - 90), 0, 0)
    # lid geometry hangs from the hinge at the origin of `lid`, standing up along +Z (rotated by open_deg - 90 back)
    box('lid-shell', (0.26, 0.008, 0.18), (0, 0.004, 0.09), mat('white', 'white'), lid, bevel=0.003)
    box('lid-screen', (0.24, 0.002, 0.16), (0, -0.0006, 0.09), mat('screen-lap', 'teal100', roughness=0.25, emission='teal100'), lid, bevel=0.001)
    # abstract dashboard: three bars and a bubble, no text
    for i, (h, x) in enumerate([(0.04, -0.07), (0.07, -0.04), (0.055, -0.01)]):
        box(f'bar{i}', (0.018, 0.0016, h), (x, -0.0016, 0.045 + h / 2), mat('teal500m', 'teal500', roughness=0.5), lid, bevel=0.0005)
    box('lap-bubble', (0.06, 0.0016, 0.03), (0.07, -0.0016, 0.12), mat('white', 'white'), lid, bevel=0.001)
    box('lap-bubble2', (0.05, 0.0016, 0.024), (0.06, -0.0016, 0.07), mat('teal300', 'teal300'), lid, bevel=0.001)
    return r


def megaphone():
    """Cone megaphone, mouth towards -Y, about 20 cm long with the handle below the body."""
    r = root('megaphone')
    # truncated cone along Y; rotated 90 about X so its wide (+Z) end points to -Y
    cyl('mega-cone', 0.024, 0.15, (0, -0.012, 0), mat('teal700', 'teal700', roughness=0.4, coat=0.2), r, r2=0.054, rot=(90, 0, 0))
    cyl('mega-lip', 0.056, 0.010, (0, -0.090, 0), mat('white', 'white', roughness=0.35), r, rot=(90, 0, 0))
    cyl('mega-band', 0.036, 0.014, (0, -0.030, 0), mat('white', 'white', roughness=0.35), r, rot=(90, 0, 0), r2=0.042)
    cyl('mega-back', 0.032, 0.05, (0, 0.085, 0), mat('teal900', 'teal900', roughness=0.4), r, rot=(90, 0, 0), r2=0.024)
    box('mega-handle', (0.022, 0.026, 0.07), (0, 0.03, -0.05), mat('ink', 'ink950', roughness=0.45), r, bevel=0.004)
    # two sound arcs in front of the mouth (thin tori read as "volume" without any text)
    for i, rad in enumerate((0.034, 0.052)):
        torus(f'arc{i}', rad, 0.003, (0, -0.118 - i * 0.026, 0), mat('teal300', 'teal300', roughness=0.4), r, rot=(90, 0, 0))
    return r


def coins():
    """Two coin stacks (5 and 3), sun-500. Coin: 4.4 cm across, 7 mm thick, with a slightly raised rim."""
    r = root('coins')
    gold = mat('coin', 'sun500', roughness=0.32, metallic=0.55)
    gold2 = mat('coin2', '#FFC96B', roughness=0.28, metallic=0.45)
    for i in range(5):
        cyl(f'coin-a{i}', 0.022, 0.007, (0, 0, 0.0035 + i * 0.0074), gold if i % 2 == 0 else gold2, r, verts=36, bevel=0.0012)
    for i in range(3):
        cyl(f'coin-b{i}', 0.022, 0.007, (0.052, -0.012, 0.0035 + i * 0.0074), gold2 if i % 2 == 0 else gold, r, verts=36, bevel=0.0012)
    # one coin standing against the stack
    cyl('coin-c', 0.022, 0.007, (-0.046, -0.02, 0.022), gold, r, rot=(78, 0, 18), verts=36, bevel=0.0012)
    return r


def clipboard():
    """Clipboard 11 x 15 cm: teal-700 board, white sheet with abstract line blocks and a tick."""
    r = root('clipboard')
    box('cb-board', (0.11, 0.008, 0.15), (0, 0, 0), mat('teal700', 'teal700', roughness=0.45), r, bevel=0.004)
    box('cb-sheet', (0.092, 0.002, 0.125), (0, -0.005, -0.004), mat('white', 'white', roughness=0.6), r, bevel=0.001)
    box('cb-clip', (0.04, 0.008, 0.016), (0, -0.0065, 0.071), mat('ink', 'ink950'), r, bevel=0.002)
    for i, (w, z) in enumerate([(0.058, 0.040), (0.050, 0.014), (0.056, -0.012), (0.040, -0.038)]):
        # a small tick box and a grey bar per row; the first two rows are "done" (teal tick box)
        box(f'cb-tick{i}', (0.012, 0.0016, 0.012), (-0.034, -0.0062, z), mat('teal500m', 'teal500' if i < 2 else 'teal100', roughness=0.5), r, bevel=0.0005)
        box(f'cb-line{i}', (w, 0.0016, 0.008), (0.010 + (0.058 - w) / 2 * -1, -0.0062, z), mat('ink200', '#D5E0E2', roughness=0.6), r, bevel=0.0005)
    return r


def magnifier():
    """Magnifying glass: ring 9 cm across, handle 8 cm. Lens looks towards -Y; handle hangs along -Z."""
    r = root('magnifier')
    torus('mag-ring', 0.044, 0.0065, (0, 0, 0.0), mat('teal700', 'teal700', roughness=0.35, coat=0.3), r, rot=(90, 0, 0))
    glass = mat('glass', 'teal100', roughness=0.05, coat=0.5, alpha=0.28)
    cyl('mag-glass', 0.0435, 0.002, (0, 0, 0), glass, r, rot=(90, 0, 0), verts=48, bevel=0)
    cyl('mag-handle', 0.0085, 0.085, (0, 0, -0.092), mat('ink', 'ink950', roughness=0.45), r)
    cyl('mag-collar', 0.0115, 0.014, (0, 0, -0.055), mat('white', 'white', roughness=0.35), r)
    # glint arc on the glass
    torus('mag-glint', 0.028, 0.0016, (0, -0.0013, 0), mat('glint', '#FFFFFF', roughness=0.2), r, rot=(90, 0, 0))
    return r


def blocks_stack(count=2, s=0.07):
    """Half-built tower of `count` blocks (edge `s`), each nudged and twisted a little so it reads as
    stacked by hand. The base sits on z = 0. Colours cycle teal, white, teal-300."""
    r = root('blocks-stack')
    colors = ['white', 'sun500', 'teal900', 'teal300']
    jitter = [(0.0, 0.0, 0), (0.006, 0.003, 7), (-0.004, 0.004, -9)]
    for i in range(count):
        dx, dy, rz = jitter[i % len(jitter)]
        box(f'block{i}', (s, s, s), (dx, dy, s / 2 + i * s), mat(f'blk-{colors[i]}', colors[i], roughness=0.5), r, bevel=0.003, rot=(0, 0, rz))
    return r


def block_single(color='teal700', s=0.07):
    r = root('block')
    box('block', (s, s, s), (0, 0, 0), mat(f'blk-{color}', color, roughness=0.5), r, bevel=0.003)
    return r


def whiteboard():
    """Small whiteboard on a two-leg easel, 42 x 30 cm board, face towards -Y. Content is abstract:
    three nodes joined by arrows (a workflow) and a sticky. No text."""
    r = root('whiteboard')
    teal = mat('teal700', 'teal700', roughness=0.4)
    box('wb-frame', (0.44, 0.016, 0.32), (0, 0, 0.30), teal, r, bevel=0.004)
    box('wb-face', (0.41, 0.004, 0.29), (0, -0.009, 0.30), mat('white', 'white', roughness=0.5), r, bevel=0.001)
    for i, x in enumerate((-0.12, 0.0, 0.12)):
        box(f'wb-node{i}', (0.07, 0.003, 0.05), (x, -0.0125, 0.31), mat(f'wbn{i}', ['teal500', 'teal300', 'teal700'][i], roughness=0.5), r, bevel=0.002)
    for x in (-0.06, 0.06):
        box('wb-arrow', (0.03, 0.003, 0.006), (x, -0.0125, 0.31), mat('ink', 'ink950'), r, bevel=0.0006)
    box('wb-bar', (0.30, 0.003, 0.008), (0, -0.0125, 0.395), mat('ink200', '#D5E0E2'), r, bevel=0.0006)
    box('wb-sticky', (0.05, 0.003, 0.05), (0.13, -0.0125, 0.225), mat('sun500', 'sun500', roughness=0.6), r, bevel=0.0008, rot=(0, 0, 0))
    box('wb-tray', (0.30, 0.03, 0.012), (0, -0.012, 0.136), teal, r, bevel=0.003)
    for sx in (-0.17, 0.17):
        box('wb-leg', (0.018, 0.018, 0.30), (sx, 0.0, 0.15), mat('ink', 'ink950', roughness=0.5), r, bevel=0.003)
        box('wb-foot', (0.03, 0.12, 0.014), (sx, 0.02, 0.007), mat('ink', 'ink950', roughness=0.5), r, bevel=0.003)
    return r


def pointer():
    """Telescopic pointer, 24 cm, ink body with a teal tip. Axis along Y, tip at -Y."""
    r = root('pointer')
    cyl('ptr-body', 0.0045, 0.20, (0, -0.0, 0), mat('ink', 'ink950', roughness=0.4), r, rot=(90, 0, 0), bevel=0.0005)
    cyl('ptr-tip', 0.0055, 0.03, (0, -0.115, 0), mat('teal500m', 'teal500', roughness=0.35), r, rot=(90, 0, 0), bevel=0.0005)
    return r


def mug():
    """Mug 7 cm tall, white glaze with a sun-500 band and coffee inside. Handle on +X."""
    r = root('mug')
    glaze = mat('white', 'white', roughness=0.3, coat=0.4)
    # hollow body: outer cylinder then a coffee disc just below the rim, the rim ring in front of it
    cyl('mug-outer', 0.034, 0.07, (0, 0, 0.035), glaze, r, verts=40, bevel=0.0015)
    torus('mug-rim', 0.0335, 0.0035, (0, 0, 0.0695), glaze, r)
    cyl('mug-coffee', 0.0325, 0.002, (0, 0, 0.066), mat('coffee', '#5A3A2C', roughness=0.2), r, verts=40, bevel=0)
    cyl('mug-band', 0.0345, 0.013, (0, 0, 0.03), mat('sun500', 'sun500', roughness=0.4), r, verts=40, bevel=0)
    torus('mug-handle', 0.019, 0.0058, (0.036, 0, 0.037), glaze, r, rot=(90, 0, 0))
    return r


def desk(width=0.46, depth=0.30, height=0.34):
    """Small work desk: white top, four ink legs. Top surface at z = height."""
    r = root('desk')
    box('desk-top', (width, depth, 0.018), (0, 0, height - 0.009), mat('white', 'white', roughness=0.4), r, bevel=0.004)
    for sx in (-1, 1):
        for sy in (-1, 1):
            box('desk-leg', (0.022, 0.022, height - 0.018), (sx * (width / 2 - 0.025), sy * (depth / 2 - 0.025), (height - 0.018) / 2), mat('ink', 'ink950', roughness=0.5), r, bevel=0.003)
    return r


def place(obj, loc, rot_deg=(0, 0, 0), scale=1.0):
    """World placement (Euler XYZ in degrees)."""
    obj.location = Vector(loc)
    obj.rotation_euler = Euler([math.radians(a) for a in rot_deg], 'XYZ')
    obj.scale = (scale, scale, scale)
    return obj


def all_children(obj):
    out = [obj]
    for c in obj.children:
        out.extend(all_children(c))
    return out
