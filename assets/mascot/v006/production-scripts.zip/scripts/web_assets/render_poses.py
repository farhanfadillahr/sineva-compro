"""Render the phase 1 Sino pose stills and the hero poster from the v005 GLB (Cycles, transparent).

  Blender -b --python scripts/web_assets/render_poses.py -- [--only sino-wave,sino-hero] [--size 1200]
                                                           [--samples 128] [--out DIR]

Per pose it writes `<name>.png` (character only, straight alpha) and `<name>_withshadow.png`
(shadow catcher on). build_web.py turns that pair into the delivered master (subtle baked contact
shadow) and the web formats.

Every pose is a frame of an existing v005 clip (idle, idle_b, listening, thinking, speaking,
greet_wave, happy_success) plus bone tweaks; no clip is edited and no v004/v005 file is touched.

Character space used below: +X is Sino's left (the wrist-gadget side), -Y is her front, +Z up, metres.
Her arms are short (shoulder to wrist about 19 cm), so gestures stay small and props are scaled to
her 6 cm hands.
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import bpy
from mathutils import Vector

import props as P
import sino_stage as SS
SS.GLB = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot/export/web/sino_v006.draco.glb'
from sino_stage import Stage, cli_args

OUT_DEFAULT = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot/export/renders/web_assets/raw'
POSES = {}


def pose(name):
    def deco(fn):
        POSES[name] = fn
        return fn
    return deco


def V(*a):
    return Vector(a)


# ---- poses ---------------------------------------------------------------------------------------

@pose('sino-hero')
def hero():
    """idle, 3/4, full body. Framed like the reference viewer (vertical FOV 32 deg, camera aimed at the
    mid-height of the figure) so the poster and the realtime canvas line up for the crossfade."""
    st = Stage('idle', 0.0)
    return st, dict(az=35, fov=32.0, shadow=False, size=1600)


@pose('sino-wave')
def wave():
    st = Stage('greet_wave', 1.0)  # peak of the clip (right hand highest at t = 1.0 s)
    # The clip only lifts the hand to hip height; raise it beside the helmet so the wave reads at card size.
    st.arm_ik('R', V(-0.28, -0.05, 0.68), pole=V(-0.45, 0.12, 0.35))
    st.hand_point('R', V(-0.15, -0.1, 1))
    st.face_camera(-35)
    st.set_morph('browInnerUp', 0.25)
    st.set_morph('mouthSmileLeft', 0.55)
    st.set_morph('mouthSmileRight', 0.55)
    return st, dict(az=-35)


@pose('sino-holding-phone')
def holding_phone():
    st = Stage('idle_b', 1.0)
    st.arm_ik('L', V(0.21, -0.16, 0.44), pole=V(0.4, 0.1, 0.30))
    st.hand_point('L', V(0.0, -0.5, 1.0))
    st.hold(P.phone(), 'L', grip_local=(0.0, 0.0, -0.015), rot_deg=(-12, 0, 38), scale=1.25)
    st.curl('L', deg=35)
    # glance at the screen: head turned towards it, eyes on it
    st.rotate_world('DEF-head', (0, 0, 1), 22)
    st.rotate_world('DEF-head', (1, 0, 0), 6)
    st.look_at(V(0.24, -0.22, 0.54))
    st.set_morph('mouthSmileLeft', 0.45)
    st.set_morph('mouthSmileRight', 0.45)
    return st, dict(az=35)


@pose('sino-laptop')
def laptop():
    st = Stage('idle', 1.0)
    for b, d in (('DEF-spine.001', 4), ('DEF-spine.002', 2)):
        st.rotate_world(b, (1, 0, 0), d)
    P.place(P.desk(height=0.25), (0.0, -0.24, 0.0))
    # Keyboard faces Sino. The lid stays beyond the hands instead of slicing through them.
    P.place(P.laptop(open_deg=105), (0.0, -0.22, 0.25), rot_deg=(0, 0, 188), scale=1.2)
    st.arm_ik('L', V(0.09, -0.17, 0.29), pole=V(0.3, 0.0, 0.35))
    st.arm_ik('R', V(-0.09, -0.17, 0.29), pole=V(-0.3, 0.0, 0.35))
    st.hand_point('L', V(0, -1, -0.2))
    st.hand_point('R', V(0, -1, -0.2))
    st.rotate_world('DEF-head', (1, 0, 0), 10)
    st.look_at(V(0.0, -0.22, 0.37))
    st.set_morph('mouthSmileLeft', 0.35)
    st.set_morph('mouthSmileRight', 0.35)
    # desk legs stand closer to the lens than Sino's feet and would touch the frame bottom at the default framing
    return st, dict(az=35, target=(0, 0, 0.5), half=0.74)


@pose('sino-megaphone')
def megaphone():
    st = Stage('speaking', 0.5)
    st.arm_ik('R', V(-0.28, -0.15, 0.45), pole=V(-0.45, -0.20, 0.30))
    st.hand_point('R', V(0.0, -0.4, 1))
    # mouth pointing up and out to her right, away from the face and not straight at the lens
    st.hold(P.megaphone(), 'R', grip_local=(0, 0.03, -0.05), rot_deg=(-20, 0, -92), scale=1.3)
    st.curl('R', deg=35)
    st.face_camera(-35)
    st.set_morph('jawOpen', 0.3)
    st.set_morph('mouthSmileLeft', 0.8)
    st.set_morph('mouthSmileRight', 0.8)
    st.set_morph('browInnerUp', 0.3)
    return st, dict(az=-35)


@pose('sino-coins')
def coins():
    st = Stage('idle', 1.0)
    st.arm_ik('L', V(0.20, -0.14, 0.44), pole=V(0.4, 0.1, 0.25))
    st.hand_point('L', V(0.0, -1.0, 0.0))
    st.rotate_local('DEF-hand.L', 'Y', 90)
    st.hold(P.coins(), 'L', grip_local=(0, 0, -0.004), rot_deg=(0, 0, 0), scale=1.4)
    st.arm_ik('R', V(-0.20, -0.17, 0.37), pole=V(-0.3, 0.0, 0.3))
    st.hand_point('R', V(0.2, -0.8, 0.4))
    st.hold(P.clipboard(), 'R', grip_local=(0.03, 0, -0.02), rot_deg=(-10, 0, 32), scale=1.4)
    st.curl('R', deg=35)
    st.rotate_world('DEF-head', (0, 0, 1), 12)
    st.look_at(V(0.2, -0.2, 0.5))
    st.set_morph('mouthSmileLeft', 0.4)
    st.set_morph('mouthSmileRight', 0.4)
    return st, dict(az=35)


@pose('sino-handshake')
def handshake():
    st = Stage('greet_wave', 0.0)
    for b, d in (('DEF-spine.001', 6), ('DEF-spine.002', 5)):
        st.rotate_world(b, (1, 0, 0), d)
    st.arm_ik('R', V(-0.10, -0.23, 0.47), pole=V(-0.35, 0.05, 0.25))
    st.hand_point('R', V(0.0, -1.0, 0.0))
    st.roll_thumb_to('R', (0, 0, 1))  # open hand, thumb up: the offering side of a handshake
    st.face_camera(-50)
    st.set_morph('mouthSmileLeft', 0.6)
    st.set_morph('mouthSmileRight', 0.6)
    st.set_morph('browInnerUp', 0.2)
    # near side view: the offered hand reads as an extended arm only when seen from the side
    return st, dict(az=-50)


@pose('sino-magnifier')
def magnifier():
    st = Stage('idle', 1.0)
    st.arm_ik('R', V(-0.27, -0.15, 0.49), pole=V(-0.4, 0.1, 0.3))
    st.hand_point('R', V(0.0, -0.3, 1))
    st.hold(P.magnifier(), 'R', grip_local=(0, 0, -0.06), rot_deg=(0, 0, 18), scale=1.35)
    st.curl('R', deg=35)
    st.rotate_world('DEF-head', (0, 0, 1), -18)
    st.look_at(V(-0.2, -0.3, 0.72))
    st.set_morph('browInnerUp', 0.5)
    st.set_morph('browOuterUpLeft', 0.3)
    st.set_morph('eyeWideLeft', 0.4)
    st.set_morph('eyeWideRight', 0.4)
    return st, dict(az=-35)


@pose('sino-blocks')
def blocks():
    st = Stage('idle', 1.0)
    for b, d in (('DEF-spine.001', 4), ('DEF-spine.002', 2)):
        st.rotate_world(b, (1, 0, 0), d)
    P.place(P.desk(width=0.50, depth=0.26), (0.09, -0.22, 0.0))
    P.place(P.blocks_stack(), (0.20, -0.20, 0.34))
    st.arm_ik('L', V(0.19, -0.15, 0.575), pole=V(0.45, 0.1, 0.3))
    st.hand_point('L', V(0.0, -0.4, -1))
    st.hold(P.block_single('teal500'), 'L', grip_local=(0, 0, 0.0), rot_deg=(0, 0, 10))
    st.curl('L', deg=30)
    st.arm_ik('R', V(-0.08, -0.14, 0.43), pole=V(-0.3, 0.0, 0.3))
    st.rotate_world('DEF-head', (1, 0, 0), 6)
    st.rotate_world('DEF-head', (0, 0, 1), 14)
    st.look_at(V(0.2, -0.2, 0.5))
    st.set_morph('mouthSmileLeft', 0.5)
    st.set_morph('mouthSmileRight', 0.5)
    return st, dict(az=35, target=(0.12, 0, 0.50), half=0.74)


@pose('sino-whiteboard')
def whiteboard():
    st = Stage('idle', 1.0)
    P.place(P.whiteboard(), (0.40, 0.0, 0.0), rot_deg=(0, 0, 22))
    st.arm_ik('L', V(0.21, -0.10, 0.56), pole=V(0.3, 0.1, 0.35))
    st.hand_point('L', V(1.0, -0.3, 0.2))
    st.hold(P.pointer(), 'L', grip_local=(0, 0.05, 0), rot_deg=(0, 0, 80), scale=1.5)
    st.curl('L', deg=35)
    st.rotate_world('DEF-head', (0, 0, 1), 22)
    st.look_at(V(0.35, -0.12, 0.62))
    st.set_morph('mouthSmileLeft', 0.45)
    st.set_morph('mouthSmileRight', 0.45)
    return st, dict(az=35, target=(0.16, 0, 0.55), half=0.70)


@pose('sino-thumbs-up')
def thumbs_up():
    st = Stage('happy_success', 0.75)
    st.arm_ik('R', V(-0.23, -0.12, 0.56), pole=V(-0.45, 0.05, 0.25))
    st.hand_point('R', V(-0.35, -1.0, 0.0))
    st.roll_thumb_to('R', (0, 0, 1))
    st.curl('R', deg=80)
    st.face_camera(-35)
    st.set_morph('blink_happy', 0.5)
    st.set_morph('mouthSmileLeft', 0.9)
    st.set_morph('mouthSmileRight', 0.9)
    st.set_morph('jawOpen', 0.12)
    return st, dict(az=-35)


@pose('sino-confused')
def confused():
    st = Stage('thinking', 1.0)  # peak of the clip: left hand raised
    st.arm_ik('L', V(0.29, -0.10, 0.60), pole=V(0.45, -0.30, 0.3))
    st.hand_point('L', V(0.3, 0.0, 1.0))
    st.curl('L', deg=40)
    st.rotate_world('DEF-head', (0, 1, 0), 11)   # head tilt (roll) towards the scratching hand
    st.rotate_world('DEF-head', (0, 0, 1), 10)
    st.look_at(V(0.3, -0.5, 1.2))
    st.set_morph('browInnerUp', 0.7)
    st.set_morph('browDownRight', 0.5)
    st.set_morph('browOuterUpLeft', 0.5)
    st.set_morph('mouthFrownLeft', 0.5)
    st.set_morph('mouthFrownRight', 0.35)
    st.set_morph('mouthRight', 0.4)
    return st, dict(az=35)


@pose('sino-relaxed')
def relaxed():
    st = Stage('idle_b', 2.0)
    st.arm_ik('R', V(-0.13, -0.15, 0.40), pole=V(-0.35, 0.05, 0.22))
    st.hand_point('R', V(0.0, -1.0, 0.2))
    st.rotate_local('DEF-hand.R', 'Y', -60)
    st.hold(P.mug(), 'R', grip_local=(0.0, 0, 0.0), rot_deg=(0, 0, 0), scale=1.25)
    st.curl('R', deg=30)
    st.rotate_world('DEF-head', (0, 1, 0), -5)
    st.set_morph('eyeBlinkLeft', 0.25)
    st.set_morph('eyeBlinkRight', 0.25)
    st.set_morph('smile_closed_soft', 0.7)
    return st, dict(az=-35)


def main():
    a = cli_args()
    only = a[a.index('--only') + 1].split(',') if '--only' in a else list(POSES)
    size = int(a[a.index('--size') + 1]) if '--size' in a else 1200
    samples = int(a[a.index('--samples') + 1]) if '--samples' in a else 128
    out = a[a.index('--out') + 1] if '--out' in a else OUT_DEFAULT
    os.makedirs(out, exist_ok=True)
    framing = {}
    for name in only:
        P._mats.clear()
        st, cfg = POSES[name]()
        st.studio(cfg['az'], shadow=cfg.get('shadow', True), exposure=-0.4)
        # a little less fill and world light than the first draft: keeps the teal saturated on white
        bpy.data.lights['fill'].energy = 70
        bpy.data.lights['top'].energy = 50
        bpy.data.worlds['studio-world'].node_tree.nodes['Background'].inputs[1].default_value = 0.3
        target = cfg.get('target', (0, 0, 0.55))
        half = cfg.get('half', 0.66)
        if '--target' in a:  # debug close-ups: --target x,y,z --half 0.15
            target = tuple(float(v) for v in a[a.index('--target') + 1].split(','))
            half = float(a[a.index('--half') + 1])
        az = float(a[a.index('--az') + 1]) if '--az' in a else cfg['az']
        framing[name] = st.camera(az, fov_deg=cfg.get('fov', 28.8), target=target, half=half)
        # the same camera in three.js coordinates (Y up, front +Z): (x, y, z) Blender -> (x, z, -y)
        c, t = framing[name]['position'], framing[name]['target']
        framing[name]['three_js'] = {'camera_position': [c[0], c[2], -c[1]], 'target': [t[0], t[2], -t[1]],
                                     'vertical_fov_deg': framing[name]['fov_deg'], 'aspect': 1.0}
        px = cfg.get('size', size) if size == 1200 else size
        st.render_pair(os.path.join(out, name), px, samples)
        print('POSE DONE', name, flush=True)
    with open(os.path.join(out, 'framing.json'), 'w') as f:
        json.dump(framing, f, indent=1)


main()
