"""Shared stage for the web pose stills: import the v005 draco GLB, freeze a clip frame into a static
pose, add bone tweaks, light it, frame it and render it (Cycles, transparent).

Imported by render_poses.py (run through Blender, not plain Python):
  Blender -b --python scripts/web_assets/render_poses.py -- ...

Why the GLB and not blender/sino_master_v005_web.blend: the stills have to match what the realtime
canvas shows. The GLB is the shipped asset (same materials, same decimation), and importing it gives
the clips as NLA tracks, so a "frame of an existing clip" is literally that clip evaluated at that frame.

Why freeze the pose into plain pose-bone values instead of tweaking on top of the NLA: the NLA
re-evaluates on every frame change and would overwrite manual bone edits. Freezing = read the
evaluated pose, delete the animation data, write the values back, then edit freely.
"""
import math
import os
import sys

import bpy
from mathutils import Euler, Matrix, Quaternion, Vector

GLB = '/Users/mhmdfaishal/Works/Projects/sineva/sino-3d-mascot/export/web/sino_v006.draco.glb'
FPS = 24

# Brand palette (tokens.md). Props use these only; sun-500 is reserved for coins and the mug band.
PALETTE = {
    'teal500': '#00949B', 'teal700': '#00686D', 'teal300': '#6CC6C9', 'teal100': '#D3EEEE',
    'teal900': '#083F4C', 'ink950': '#0B2A31', 'white': '#F4F8F8', 'sun500': '#FFB547',
    'sun100': '#FFF4E5', 'aqua400': '#2FE0D8',
}


def srgb_to_linear(hex_color):
    h = hex_color.lstrip('#')
    out = []
    for i in (0, 2, 4):
        c = int(h[i:i + 2], 16) / 255
        out.append(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4)
    return tuple(out) + (1.0,)


def material(name, color, roughness=0.45, metallic=0.0, coat=0.0, emission=None, alpha=1.0):
    """Principled material from a brand hex. Props stay matte-soft like the suit; `coat` adds the
    helmet-style gloss only where a prop needs it (lens, mug glaze)."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = next(n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')
    bsdf.inputs['Base Color'].default_value = srgb_to_linear(PALETTE.get(color, color))
    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic
    for key in ('Coat Weight', 'Clearcoat'):
        if key in bsdf.inputs:
            bsdf.inputs[key].default_value = coat
            break
    if emission:
        bsdf.inputs['Emission Color'].default_value = srgb_to_linear(PALETTE.get(emission, emission))
        bsdf.inputs['Emission Strength'].default_value = 1.2
    if alpha < 1.0:
        bsdf.inputs['Alpha'].default_value = alpha
    return mat


class Stage:
    def __init__(self, clip='idle', frame_time=0.0):
        bpy.ops.wm.read_factory_settings(use_empty=True)
        bpy.ops.import_scene.gltf(filepath=GLB)
        self.S = bpy.context.scene
        self.S.render.fps = FPS
        self.rig = next(o for o in self.S.objects if o.type == 'ARMATURE')
        self.meshes = [o for o in self.S.objects if o.type == 'MESH' and o.parent == self.rig]
        # The importer adds an "Icosphere" custom bone shape; it is not part of the mascot.
        for o in list(self.S.objects):
            if o.type == 'MESH' and o.parent is None:
                bpy.data.objects.remove(o, do_unlink=True)
        self.props = []
        self.set_clip(clip, frame_time)

    # ---- pose ---------------------------------------------------------------------------------
    def set_clip(self, clip, t):
        """Evaluate `clip` at `t` seconds and freeze it (bones and shape keys)."""
        rig = self.rig
        ads = [rig.animation_data] + [m.data.shape_keys.animation_data for m in self.meshes
                                      if m.data.shape_keys and m.data.shape_keys.animation_data]
        for ad in ads:
            ad.action = None
            for tr in ad.nla_tracks:
                tr.mute = tr.name != clip
        self.S.frame_set(1 + round(t * FPS))
        bpy.context.view_layer.update()
        pose = {b.name: (b.location.copy(), b.rotation_quaternion.copy(), b.scale.copy(), b.rotation_mode)
                for b in rig.pose.bones}
        keys = {}
        for m in self.meshes:
            sk = m.data.shape_keys
            if sk:
                keys[m.name] = {kb.name: kb.value for kb in sk.key_blocks}
        for ad in ads:
            for tr in list(ad.nla_tracks):
                ad.nla_tracks.remove(tr)
        for m in self.meshes:
            if m.data.shape_keys:
                m.data.shape_keys.animation_data_clear()
        rig.animation_data_clear()
        for b in rig.pose.bones:
            loc, quat, scl, mode = pose[b.name]
            b.rotation_mode = 'QUATERNION'
            b.location, b.rotation_quaternion, b.scale = loc, quat, scl
        for m in self.meshes:
            if m.name in keys:
                for kb in m.data.shape_keys.key_blocks:
                    if kb.name in keys[m.name]:
                        kb.value = keys[m.name][kb.name]
        bpy.context.view_layer.update()

    def set_morph(self, name, value):
        """Set a shape key on every mesh that has it (v005 keeps brows/blink on two meshes)."""
        for m in self.meshes:
            sk = m.data.shape_keys
            if sk and name in sk.key_blocks:
                sk.key_blocks[name].value = value

    def update(self):
        bpy.context.view_layer.update()

    def pb(self, name):
        return self.rig.pose.bones[name]

    def head_w(self, name):
        return self.rig.matrix_world @ self.pb(name).head

    def tail_w(self, name):
        return self.rig.matrix_world @ self.pb(name).tail

    def _apply_world(self, name, M):
        b = self.pb(name)
        mw = self.rig.matrix_world
        b.matrix = mw.inverted() @ M @ mw @ b.matrix
        self.update()

    def rotate_world(self, name, axis, deg, pivot=None):
        """Rotate a bone (and its children) about a world axis through `pivot` (default its head)."""
        p = pivot if pivot is not None else self.head_w(name)
        R = Matrix.Rotation(math.radians(deg), 4, Vector(axis).normalized())
        self._apply_world(name, Matrix.Translation(p) @ R @ Matrix.Translation(-p))

    def rotate_local(self, name, axis, deg):
        """Rotate about a bone-local axis ('X', 'Y' or 'Z'); Y is the bone's own length axis."""
        b = self.pb(name)
        mw = self.rig.matrix_world
        ax = (mw.to_3x3() @ b.matrix.to_3x3() @ Vector({'X': (1, 0, 0), 'Y': (0, 1, 0), 'Z': (0, 0, 1)}[axis])).normalized()
        self.rotate_world(name, ax, deg)

    def aim(self, name, child, target):
        """Swing `name` so the line head -> child.head points at `target` (minimal rotation)."""
        cur = (self.head_w(child) - self.head_w(name)).normalized()
        des = (Vector(target) - self.head_w(name)).normalized()
        q = cur.rotation_difference(des)
        p = self.head_w(name)
        self._apply_world(name, Matrix.Translation(p) @ q.to_matrix().to_4x4() @ Matrix.Translation(-p))

    def look_at(self, point, limit_deg=28.0):
        """Aim both eye bones (their +Y points forward) at a world point, clamped so a big turn does not
        push the iris past the lids. Rotating the bone moves the painted iris; the lids do not follow
        (no eyeLook corrective is driven here), so keep the angle moderate."""
        for n in ('DEF-eye.L', 'DEF-eye.R'):
            h = self.head_w(n)
            cur = (self.tail_w(n) - h).normalized()
            des = (Vector(point) - h).normalized()
            q = cur.rotation_difference(des)
            ang = math.degrees(q.angle)
            if ang > limit_deg:
                q = Quaternion().slerp(q, limit_deg / ang)
            self._apply_world(n, Matrix.Translation(h) @ q.to_matrix().to_4x4() @ Matrix.Translation(-h))

    def arm_ik(self, side, target, pole):
        """Analytic two-bone IK: put the hand bone head on `target`, elbow bent towards `pole`.
        Done by hand rather than with an IK constraint because constraints need an evaluated depsgraph
        round trip per bone; this keeps pose building a pure function of numbers."""
        up, fore, hand = f'DEF-upper_arm.{side}', f'DEF-forearm.{side}', f'DEF-hand.{side}'
        S, E0, H0 = self.head_w(up), self.head_w(fore), self.head_w(hand)
        l1, l2 = (E0 - S).length, (H0 - E0).length
        T = Vector(target)
        d_vec = T - S
        d = min(max(d_vec.length, abs(l1 - l2) + 1e-4), l1 + l2 - 1e-4)
        dirn = d_vec.normalized()
        a = (l1 ** 2 - l2 ** 2 + d ** 2) / (2 * d)
        h = math.sqrt(max(l1 ** 2 - a ** 2, 0.0))
        pv = Vector(pole) - S
        pv = (pv - dirn * pv.dot(dirn)).normalized()
        E = S + dirn * a + pv * h
        self.aim(up, fore, E)
        self.aim(fore, hand, S + dirn * d)

    def hand_point(self, side, direction):
        """Point the palm axis (hand head -> SOCKET) along a world direction."""
        h = self.head_w(f'DEF-hand.{side}')
        self.aim(f'DEF-hand.{side}', f'SOCKET-hand.{side}', h + Vector(direction))

    def roll_thumb_to(self, side, up=(0, 0, 1)):
        """Roll the hand about its palm axis (wrist -> SOCKET) until the thumb base sits on the `up` side.
        Used for handshake and thumbs-up, where the thumb direction is the whole point; a fixed local
        roll is not enough because the arm IK changes the forearm roll for every target."""
        hand = f'DEF-hand.{side}'
        h = self.head_w(hand)
        axis = (self.head_w(f'SOCKET-hand.{side}') - h).normalized()
        t = self.head_w(f'DEF-thumb.01.{side}') - h
        t = (t - axis * t.dot(axis)).normalized()
        u = Vector(up)
        u = (u - axis * u.dot(axis)).normalized()
        ang = math.degrees(math.acos(max(-1.0, min(1.0, t.dot(u)))))
        sign = 1.0 if t.cross(u).dot(axis) >= 0 else -1.0
        self.rotate_world(hand, axis, sign * ang)

    def socket(self, side):
        return self.rig.matrix_world @ self.pb(f'SOCKET-hand.{side}').matrix

    def curl(self, side, fingers=('index', 'middle', 'ring'), deg=60, thumb=None):
        """Close the fingers (`deg` > 0 closes). In this rig a NEGATIVE rotation about each finger bone's
        local X closes the glove on both hands (checked on close-ups; the positive direction folds the
        mesh the wrong way and tears the glove). The second joint bends a little more than the first.
        `thumb` bends the thumb the same way; leave it None for a thumb that stays out."""
        for f in fingers:
            for i in ('01', '02'):
                self.rotate_local(f'DEF-{f}.{i}.{side}', 'X', -(deg if i == '01' else deg * 1.1))
        if thumb is not None:
            for i in ('01', '02'):
                self.rotate_local(f'DEF-thumb.{i}.{side}', 'X', -thumb)

    def face_camera(self, az_deg, amount=0.55, gaze=True):
        """Turn the head towards the camera (the body keeps the 3/4 view) and, if `gaze`, aim the eyes at it."""
        self.rotate_world('DEF-head', (0, 0, 1), az_deg * amount)
        if gaze:
            a = math.radians(az_deg)
            self.look_at(Vector((math.sin(a), -math.cos(a), 0.78)) * 2.6)

    def hold(self, prop, side, grip_local=(0, 0, 0), rot_deg=(0, 0, 0), scale=1.0):
        """Put `prop` in the hand: its local point `grip_local` lands on the glove's SOCKET bone and
        it is oriented by `rot_deg` (world XYZ Euler). Parented to the SOCKET bone, so it moves with
        the hand if the pose is edited afterwards."""
        R = Euler([math.radians(a) for a in rot_deg], 'XYZ').to_matrix()
        sock = self.socket(side).to_translation()
        prop.rotation_euler = Euler([math.radians(a) for a in rot_deg], 'XYZ')
        prop.scale = (scale, scale, scale)
        prop.location = sock - R @ (Vector(grip_local) * scale)
        bpy.context.view_layer.update()
        self.add_prop(prop, f'SOCKET-hand.{side}')
        return prop

    # ---- props --------------------------------------------------------------------------------
    def add_prop(self, obj, parent_bone=None):
        """Register a prop. With `parent_bone` it is parented to that bone keeping its world
        transform, so it follows the hand like a real attachment."""
        if parent_bone:
            mw = obj.matrix_world.copy()
            obj.parent = self.rig
            obj.parent_type = 'BONE'
            obj.parent_bone = parent_bone
            # Bone parenting is relative to the bone TAIL in Blender; the inverse of the posed bone
            # matrix (translated to the tail) cancels that so the prop does not jump.
            b = self.pb(parent_bone)
            bone_m = self.rig.matrix_world @ b.matrix @ Matrix.Translation((0, b.length, 0))
            obj.matrix_parent_inverse = bone_m.inverted()
            obj.matrix_world = mw
        self.props.append(obj)
        return obj

    # ---- studio -------------------------------------------------------------------------------
    def studio(self, az_deg=35.0, shadow=True, key_power=520, exposure=0.0):
        """Bright studio, defined in camera space and rotated with the camera azimuth so "key upper
        left" holds for any view. Sizes and powers follow IMPLEMENTATION_PLAN.md 14.1, rebalanced
        by eye for the light UI (the plan's rig was tuned for a dark backdrop)."""
        S = self.S
        rig = bpy.data.objects.new('studio', None)
        S.collection.objects.link(rig)
        rig.rotation_euler = (0, 0, math.radians(az_deg))
        self.studio_rig = rig

        def area(name, size, power, color, loc, shape='SQUARE', size_y=None):
            d = bpy.data.lights.new(name, 'AREA')
            d.shape = shape
            d.size = size
            if size_y:
                d.size_y = size_y
            d.energy = power
            d.color = color
            o = bpy.data.objects.new(name, d)
            S.collection.objects.link(o)
            o.parent = rig
            o.location = loc
            # aim the light's -Z at the character's chest
            tgt = Vector((0, 0, 0.55))
            o.rotation_euler = (tgt - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
            # parented in rig space: the track above is in rig space too, so it stays aimed
            return o

        # camera sits at -Y in rig space; camera-left = -X. Key: 45 deg left, 35 deg up, 3 m away.
        def pol(az, el, dist):
            a, e = math.radians(az), math.radians(el)
            return (math.sin(a) * math.cos(e) * dist, -math.cos(a) * math.cos(e) * dist, 0.55 + math.sin(e) * dist)

        area('key', 2.2, key_power, (1.0, 0.97, 0.93), pol(-45, 35, 3.2))
        area('fill', 2.8, 140, (0.88, 0.94, 1.0), pol(60, 10, 3.0))
        area('top', 1.6, 90, (1, 1, 1), pol(0, 80, 2.8))
        # teal rim, from behind-right, thin strip; #80D2D2 per the brand dark-mode accent
        area('rim', 0.5, 260, srgb_to_linear('#80D2D2')[:3], pol(140, 25, 2.8), shape='RECTANGLE', size_y=2.2)
        # face light: the face sits inside the helmet and would otherwise be in its shadow
        area('face', 0.5, 45, (1.0, 0.96, 0.9), pol(-8, 12, 2.6))

        w = bpy.data.worlds.new('studio-world')
        S.world = w
        w.use_nodes = True
        bg = next(n for n in w.node_tree.nodes if n.type == 'BACKGROUND')
        bg.inputs[0].default_value = (0.86, 0.9, 0.92, 1)
        bg.inputs[1].default_value = 0.55

        if shadow:
            bpy.ops.mesh.primitive_plane_add(size=10, location=(0, 0, 0))
            g = bpy.context.active_object
            g.name = 'ground-shadow-catcher'
            g.is_shadow_catcher = True
            g.hide_render = True  # only visible during the shadow pass (render_pair)
            self.ground = g
        else:
            self.ground = None

        v = S.view_settings
        v.view_transform = 'AgX'
        looks = [i.identifier for i in bpy.types.ColorManagedViewSettings.bl_rna.properties['look'].enum_items]
        pick = [l for l in looks if 'Medium Contrast' in l]
        v.look = pick[0] if pick else v.look
        v.exposure = exposure
        S.display_settings.display_device = 'sRGB'

    def camera(self, az_deg=35.0, target=(0, 0, 0.55), fov_deg=28.8, half=0.66, dist=None, pitch_deg=0.0):
        """Perspective camera at azimuth `az` looking at `target`. `fov_deg` is the vertical FOV of a
        square frame (28.8 deg = 70 mm on a 36 mm sensor). `half` = half the visible height in metres at
        the target distance, which fixes the distance unless `dist` is given."""
        S = self.S
        cd = bpy.data.cameras.new('cam')
        cd.sensor_fit = 'VERTICAL'
        cd.sensor_height = 24.0
        cd.lens = 12.0 / math.tan(math.radians(fov_deg) / 2)
        cam = bpy.data.objects.new('cam', cd)
        S.collection.objects.link(cam)
        S.camera = cam
        t = Vector(target)
        d = dist if dist else half / math.tan(math.radians(fov_deg) / 2)
        az = math.radians(az_deg)
        pitch = math.radians(pitch_deg)
        cam.location = t + Vector((math.sin(az) * math.cos(pitch) * d, -math.cos(az) * math.cos(pitch) * d, math.sin(pitch) * d))
        cam.rotation_euler = (t - cam.location).to_track_quat('-Z', 'Y').to_euler()
        self.cam = cam
        return {'position': tuple(round(c, 4) for c in cam.location), 'target': tuple(t), 'fov_deg': fov_deg}

    # ---- render -------------------------------------------------------------------------------
    def render(self, path, size, samples=128, shadow_only_alpha=False):
        S = self.S
        S.render.engine = 'CYCLES'
        try:
            pref = bpy.context.preferences.addons['cycles'].preferences
            pref.compute_device_type = 'METAL'
            pref.refresh_devices()
            for d in pref.devices:
                d.use = d.type == 'METAL'
            S.cycles.device = 'GPU'
        except Exception as e:  # CPU fallback keeps the script usable on machines without Metal
            print('GPU setup failed, CPU fallback:', e)
        S.cycles.samples = samples
        S.cycles.use_adaptive_sampling = True
        S.cycles.adaptive_threshold = 0.01
        S.cycles.use_denoising = True
        S.cycles.max_bounces = 8
        S.cycles.caustics_reflective = False
        S.cycles.caustics_refractive = False
        S.cycles.pixel_filter_type = 'BLACKMAN_HARRIS'
        S.cycles.filter_width = 1.5
        S.render.film_transparent = True
        S.render.resolution_x = S.render.resolution_y = size
        S.render.resolution_percentage = 100
        S.render.image_settings.file_format = 'PNG'
        S.render.image_settings.color_mode = 'RGBA'
        S.render.image_settings.color_depth = '8'
        # A stale compositor group in a file blanks the output (see the Blender MCP notes).
        S.render.use_compositing = False
        S.render.use_sequencer = False
        S.render.filepath = path
        bpy.ops.render.render(write_still=True)

    def render_pair(self, base, size, samples=128):
        """Two renders per pose: `<base>.png` (no ground) and `<base>_withshadow.png` (shadow catcher on).
        Post-processing derives the shadow layer as (with_shadow.alpha - plain.alpha), which lets the
        shadow be scaled or dropped without re-rendering.

        The shadow pass is lit by one soft overhead light only, not the studio rig: the key light sits
        35 deg up and throws a long streak across the floor, while a contact shadow should be a short
        soft pool under the feet (mascot-sino.md section 4)."""
        self.render(f'{base}.png', size, samples)
        if not self.ground:
            return
        for name in ('key', 'fill', 'rim', 'face'):
            bpy.data.objects[name].hide_render = True
        top = bpy.data.objects['top']
        top.data.energy = 420
        top.data.size = 1.4
        top.location = Vector((-0.25, -0.2, 2.6))
        top.rotation_euler = (Vector((0, 0, 0.3)) - top.location).to_track_quat('-Z', 'Y').to_euler()
        # world light would otherwise wash the shadow out; keep a little for a soft penumbra
        bg = next(n for n in self.S.world.node_tree.nodes if n.type == 'BACKGROUND')
        bg.inputs[1].default_value = 0.12
        self.ground.hide_render = False
        self.ground.is_shadow_catcher = True
        self.render(f'{base}_withshadow.png', size, max(48, samples // 2))


def cli_args():
    return sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
