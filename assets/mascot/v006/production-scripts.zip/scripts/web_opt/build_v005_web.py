"""Build blender/sino_master_v005_web.blend from v004: web-budget geometry, merged meshes, trimmed materials.

Run (v004 is only read; the first operation re-targets the session to the v005 file):
  Blender -b blender/sino_master_v004.blend --python scripts/web_opt/build_v005_web.py

What it does, and why each step is done this way
- Drops the stray scene ('Scene': Cube/Light/Camera). The glTF exporter walks every scene unless told otherwise,
  which is how a Cube node and a second scene ended up in sino.glb.
- Materials: cornea alpha 0.2; clearcoat only on MAT-helmet_shell, sheen only on MAT-rim_pad.
- Bakes every non-armature modifier (subsurf, solidify, bevel, shrinkwrap...) into real mesh data, then collapses
  triangles to a per-object target. Baking first and decimating the *evaluated* result keeps silhouettes better
  than lowering subsurf levels, and the exporter then has nothing left to apply.
- Meshes WITH shape keys cannot go through the Decimate modifier (it drops the keys). They are decimated on the
  basis and every key is re-projected onto the new vertices through the nearest original triangle (barycentric
  delta transfer). Verified numerically at the end of the run.
- Joins: all static meshes into one object (the exporter then emits one primitive per material); head + eyelid caps
  into the head; lash/brow/crease strips into one 7-key face-detail mesh. Joining requires identical key lists,
  so every key list is normalised before the join.
"""
import bpy, bmesh, sys, json
import numpy as np
from pathlib import Path
from mathutils import bvhtree, interpolate

BASE = Path(bpy.data.filepath).resolve().parents[1] if bpy.data.filepath else Path('.').resolve()
V4 = BASE / 'blender/sino_master_v004.blend'
V5 = BASE / 'blender/sino_master_v005_web.blend'
REPORT = BASE / 'export/web/v005_build_report.json'
assert Path(bpy.data.filepath).resolve() == V4.resolve(), 'run with v004 opened (it is only read)'
bpy.ops.wm.save_as_mainfile(filepath=str(V5))     # from here on every save goes to v005
assert Path(bpy.data.filepath).resolve() == V5.resolve()

# Per-object triangle targets (evaluated, i.e. after subsurf/solidify/bevel at viewport levels).
# Visible, curved, high-contrast parts keep more; buried and tiny-detail parts lose most.
TARGETS = json.loads(Path(__file__).with_name('targets_v005.json').read_text())
BEVEL_SEGMENTS = TARGETS.pop('_bevel_segments')        # bevel-only boxes/cylinders: fewer chamfer segments instead of decimation
TRIM_BACK = {'GEO-eye.L', 'GEO-eye.R', 'GEO-cornea.L', 'GEO-cornea.R'}   # iris/pupil are vertex colours on the front: delete the hidden back half, spend the budget on the front
HAIR_TOP = {'GEO-hair'}                                  # Decimate sits above subsurf, subsurf is off (same as the old export)
SK_COMMON = {  # shape-key objects -> key list every member of the join group is padded to
    'head': None,   # filled from GEO-head
    'detail': ['eyeBlinkLeft', 'eyeBlinkRight', 'browDownLeft', 'browDownRight', 'browOuterUpLeft', 'browOuterUpRight', 'browInnerUp'],
}

S = bpy.context.scene
rig = bpy.data.objects['RIG-sino']
S.frame_set(0)
log = {'objects': {}}


def tri_count(me):
    me.calc_loop_triangles()
    return len(me.loop_triangles)


def depsgraph():
    return bpy.context.evaluated_depsgraph_get()


# 1. stray scene -------------------------------------------------------------------------
stray = bpy.data.scenes.get('Scene')
assert stray is not None and stray != S
for o in list(stray.objects):
    bpy.data.objects.remove(o, do_unlink=True)
bpy.data.scenes.remove(stray)
if 'Material' in bpy.data.materials and bpy.data.materials['Material'].users == 0:
    bpy.data.materials.remove(bpy.data.materials['Material'])

# Actions are only referenced through NLA strips / the old shape-key datablocks that this script replaces;
# without a fake user the face actions would be dropped when the file is saved.
for a in bpy.data.actions:
    a.use_fake_user = True

# 2. materials ----------------------------------------------------------------------------
def principled(m):
    return next(n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')

try:   # the exporter's own constant for "no clearcoat roughness extension needed"
    from io_scene_gltf2.io.com.constants import BLENDER_COAT_ROUGHNESS as COAT_ROUGHNESS_DEFAULT
except ImportError:
    COAT_ROUGHNESS_DEFAULT = 0.03
mat_log = {}
for m in bpy.data.materials:
    if not m.use_nodes or not m.node_tree: continue
    p = next((n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if p is None: continue
    before = {k: round(p.inputs[k].default_value, 3) for k in ('Alpha', 'Coat Weight', 'Sheen Weight', 'Transmission Weight')}
    if m.name == 'MAT-cornea':
        p.inputs['Transmission Weight'].default_value = 0.0
        p.inputs['Alpha'].default_value = 0.2
    if m.name != 'MAT-helmet_shell':
        p.inputs['Coat Weight'].default_value = 0.0
        # The exporter still writes KHR_materials_clearcoat when the coat roughness differs from Blender's default.
        p.inputs['Coat Roughness'].default_value = COAT_ROUGHNESS_DEFAULT
    if m.name != 'MAT-rim_pad': p.inputs['Sheen Weight'].default_value = 0.0
    mat_log[m.name] = {'before': before, 'after': {k: round(p.inputs[k].default_value, 3) for k in before}}
log['materials'] = mat_log

# 3. decimate / bake ----------------------------------------------------------------------
export_meshes = [o for o in rig.children_recursive if o.type == 'MESH' and not o.hide_render]


def eval_mesh(obj, decimate_ratio=None, decimate_top=False, skip=('ARMATURE',), off=()):
    """Evaluate `obj` with armature (and `off` modifiers) disabled, optionally with a Collapse decimate; return a new Mesh."""
    saved = [(m, m.show_viewport) for m in obj.modifiers]
    for m in obj.modifiers:
        if m.type in skip or m.type in off: m.show_viewport = False
    dec = None
    if decimate_ratio is not None:
        dec = obj.modifiers.new('WebDecimate', 'DECIMATE')
        dec.decimate_type = 'COLLAPSE'; dec.ratio = decimate_ratio; dec.use_collapse_triangulate = True
        if decimate_top: obj.modifiers.move(len(obj.modifiers) - 1, 0)
    dg = depsgraph()
    ev = obj.evaluated_get(dg)
    me = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=True, depsgraph=dg)
    if dec: obj.modifiers.remove(dec)
    for m, v in saved: m.show_viewport = v
    return me


def eval_tris(obj, **kw):
    me = eval_mesh(obj, **kw); n = tri_count(me); bpy.data.meshes.remove(me); return n


def finish(obj, me, was_smooth):
    """Swap in the baked mesh, drop the baked modifiers, restore smooth shading lost by the collapse."""
    for m in list(obj.modifiers):
        if m.type != 'ARMATURE': obj.modifiers.remove(m)
        else: m.show_viewport = True
    old = obj.data
    obj.data = me
    me.name = old.name
    # Collapses on solidified/thin meshes leave coincident duplicate faces (exporter warns 'mesh is not valid').
    n_before = len(me.polygons)
    me.validate(verbose=False)
    if len(me.polygons) != n_before: log.setdefault('duplicate_faces_removed', {})[obj.name] = n_before - len(me.polygons)
    if old.users == 0: bpy.data.meshes.remove(old)
    if was_smooth:
        me.polygons.foreach_set('use_smooth', [True] * len(me.polygons)); me.update()


def trim_back(me, obj, min_world_y=0.1):
    """Delete faces that face away from the camera side (the character looks down -Y)."""
    rot = obj.matrix_world.to_3x3()
    bm = bmesh.new(); bm.from_mesh(me)
    bm.faces.ensure_lookup_table()
    dead = [f for f in bm.faces if (rot @ f.normal).y > min_world_y]
    bmesh.ops.delete(bm, geom=dead, context='FACES')
    bm.to_mesh(me); bm.free(); me.update()
    log.setdefault('back_faces_trimmed', {})[obj.name] = len(dead)


def auto_sharp(me, angle_deg=35.0):
    """Smooth faces, sharp creases above `angle_deg`. Used where a collapse follows a bevel + weighted-normal stack,
    whose custom normals do not survive a collapse."""
    import math
    try: me.customdata_custom_splitnormals_clear()
    except (AttributeError, RuntimeError): pass
    bm = bmesh.new(); bm.from_mesh(me)
    lim = math.radians(angle_deg)
    for e in bm.edges:
        if len(e.link_faces) == 2: e.smooth = e.calc_face_angle(0.0) < lim
    for f in bm.faces: f.smooth = True
    bm.to_mesh(me); bm.free(); me.update()


def smooth_fraction(me):
    return sum(p.use_smooth for p in me.polygons) / max(1, len(me.polygons))


def process_static(obj):
    name = obj.name
    has_bevel = any(m.type == 'BEVEL' for m in obj.modifiers)
    hair = name in HAIR_TOP
    off = ('SUBSURF',) if hair else ()
    was_smooth = smooth_fraction(obj.data) > 0.95 and not any(m.type == 'WEIGHTED_NORMAL' for m in obj.modifiers)
    for m in obj.modifiers:
        if m.type == 'BEVEL': m.segments = min(m.segments, BEVEL_SEGMENTS)
    before = eval_tris(obj)  # (hair: with its subsurf, as stored in the master)
    n0 = eval_tris(obj, off=off) if hair else before
    target = TARGETS.get(name)
    ratio = None
    if target and target < n0 * 0.97: ratio = target / n0
    if name in TRIM_BACK:
        # Bake first, cut the hidden back hemisphere, then collapse what is left so the whole budget lands on the visible front.
        me0 = eval_mesh(obj, off=off)
        trim_back(me0, obj)
        finish(obj, me0, False)
        n0 = tri_count(obj.data)
        ratio = target / n0 if target and target < n0 * 0.97 else None
        was_smooth = True
    me = eval_mesh(obj, decimate_ratio=ratio, decimate_top=hair, off=off)
    finish(obj, me, was_smooth and ratio is not None)
    if has_bevel and ratio is not None: auto_sharp(obj.data)
    log['objects'][name] = {'before': before, 'after': tri_count(obj.data), 'ratio': ratio and round(ratio, 4), 'bevel_segments': BEVEL_SEGMENTS if has_bevel else None}


def process_shape_keys(obj, key_list, target):
    """Decimate a mesh that owns shape keys by delta transfer, and rebuild its key list in `key_list` order."""
    me = obj.data; sk = me.shape_keys
    for m in list(obj.modifiers):
        if m.type == 'SUBSURF':          # the web export always ran with the head's subsurf off (keys are lost otherwise)
            obj.modifiers.remove(m)
    ref = sk.reference_key
    assert all(k.relative_key == ref for k in sk.key_blocks), obj.name
    n = len(me.vertices)
    base = np.empty(n * 3); ref.data.foreach_get('co', base); base = base.reshape(n, 3)
    cur = np.empty(n * 3); me.vertices.foreach_get('co', cur)
    assert np.abs(cur.reshape(n, 3) - base).max() < 1e-6, 'mesh coordinates differ from the reference key'
    deltas = {}
    for k in sk.key_blocks:
        if k == ref: continue
        a = np.empty(n * 3); k.data.foreach_get('co', a); deltas[k.name] = a.reshape(n, 3) - base
    limits = {k.name: (k.slider_min, k.slider_max) for k in sk.key_blocks}
    before = tri_count(me)
    # decimate a key-less copy
    tmp = obj.copy(); tmp.data = me.copy(); bpy.context.collection.objects.link(tmp)
    tmp.shape_key_clear()
    for m in list(tmp.modifiers): tmp.modifiers.remove(m)
    ratio = target / before if target and target < before * 0.97 else None
    if ratio:
        dec = tmp.modifiers.new('WebDecimate', 'DECIMATE'); dec.decimate_type = 'COLLAPSE'; dec.ratio = ratio; dec.use_collapse_triangulate = True
    dg = depsgraph()
    new = bpy.data.meshes.new_from_object(tmp.evaluated_get(dg), preserve_all_data_layers=True, depsgraph=dg)
    old_tmp_me = tmp.data
    bpy.data.objects.remove(tmp); bpy.data.meshes.remove(old_tmp_me)
    m_n = len(new.vertices)
    newco = np.empty(m_n * 3); new.vertices.foreach_get('co', newco); newco = newco.reshape(m_n, 3)
    if ratio:
        me.calc_loop_triangles()
        tris = [tuple(t.vertices) for t in me.loop_triangles]
        tree = bvhtree.BVHTree.FromPolygons([tuple(v) for v in base], tris)
        tri_idx = np.zeros((m_n, 3), dtype=int); w = np.zeros((m_n, 3))
        maxd = 0.0
        for i in range(m_n):
            loc, nor, fi, dist = tree.find_nearest(newco[i].tolist())
            maxd = max(maxd, dist)
            tv = tris[fi]; tri_idx[i] = tv
            w[i] = interpolate.poly_3d_calc([base[j].tolist() for j in tv], loc)
        def transfer(d): return (w[:, :, None] * d[tri_idx]).sum(axis=1)
    else:
        assert m_n == n; maxd = 0.0
        def transfer(d): return d
    was_smooth = smooth_fraction(me) > 0.95
    finish(obj, new, was_smooth and bool(ratio))
    obj.shape_key_add(name='Basis', from_mix=False)
    for name in key_list:
        kb = obj.shape_key_add(name=name, from_mix=False)
        d = transfer(deltas[name]) if name in deltas else np.zeros((m_n, 3))
        kb.data.foreach_set('co', (newco + d).ravel())
        kb.slider_min, kb.slider_max = limits.get(name, (0.0, 1.0)); kb.value = 0.0
    log['objects'][obj.name] = {'before': before, 'after': tri_count(obj.data), 'ratio': ratio and round(ratio, 4), 'max_projection_distance_m': round(maxd, 6), 'keys': len(key_list)}


head = bpy.data.objects['GEO-head']
SK_COMMON['head'] = [k.name for k in head.data.shape_keys.key_blocks if k != head.data.shape_keys.reference_key]
sk_objs = [o for o in export_meshes if o.data.shape_keys]
head_group = [head] + [o for o in sk_objs if o.name.startswith('GEO-head_lid')]
detail_group = [o for o in sk_objs if o not in head_group]
static_objs = [o for o in export_meshes if not o.data.shape_keys]
print('static', len(static_objs), 'head group', [o.name for o in head_group], 'detail group', [o.name for o in detail_group])

# reference values for the post-join numeric check: world-space-free key displacement per object at weight 1
ref_disp = {}
for o in sk_objs:
    me = o.data; sk = me.shape_keys; n = len(me.vertices)
    for k in sk.key_blocks:
        if k == sk.reference_key: continue
        a = np.empty(n * 3); k.data.foreach_get('co', a)
        b = np.empty(n * 3); sk.reference_key.data.foreach_get('co', b)
        ref_disp.setdefault(k.name, 0.0)
        ref_disp[k.name] += float(np.linalg.norm((a - b).reshape(n, 3), axis=1).sum())

for o in static_objs: process_static(o)
for o in head_group: process_shape_keys(o, SK_COMMON['head'], TARGETS.get(o.name))
for o in detail_group: process_shape_keys(o, SK_COMMON['detail'], TARGETS.get(o.name))

# 4. joins ----------------------------------------------------------------------------------
def join(active, others, new_name):
    for o in bpy.data.objects:
        try: o.select_set(False)
        except RuntimeError: pass
    objs = [active] + others
    for o in objs:
        o.hide_set(False); o.hide_viewport = False; o.select_set(True)
    bpy.context.view_layer.objects.active = active
    with bpy.context.temp_override(active_object=active, selected_objects=objs, selected_editable_objects=objs, object=active):
        res = bpy.ops.object.join()
    assert res == {'FINISHED'}, res
    active.name = new_name; active.data.name = new_name
    return active

body_active = next(o for o in static_objs if o.name == 'GEO-body_suit')
body = join(body_active, [o for o in static_objs if o is not body_active], 'GEO-web_body')
head = join(head, [o for o in head_group if o is not head], 'GEO-head')
detail = join(detail_group[0], detail_group[1:], 'GEO-web_face_detail')

# 5. checks ---------------------------------------------------------------------------------
joined_disp = {}
for o in (head, detail):
    me = o.data; sk = me.shape_keys; n = len(me.vertices)
    assert [k.name for k in sk.key_blocks][1:] == (SK_COMMON['head'] if o is head else SK_COMMON['detail']), (o.name, [k.name for k in sk.key_blocks][:5])
    b = np.empty(n * 3); sk.reference_key.data.foreach_get('co', b)
    for k in sk.key_blocks:
        if k == sk.reference_key: continue
        a = np.empty(n * 3); k.data.foreach_get('co', a)
        joined_disp[k.name] = joined_disp.get(k.name, 0.0) + float(np.linalg.norm((a - b).reshape(n, 3), axis=1).sum())
# Total displacement shrinks with fewer vertices; the check is that every original key still moves geometry.
dead = [k for k in ref_disp if ref_disp[k] > 1e-6 and joined_disp.get(k, 0.0) < 1e-6]
log['keys_with_motion_lost'] = dead
log['key_displacement_ratio_joined_over_original'] = {k: round(joined_disp.get(k, 0) / ref_disp[k], 3) for k in ref_disp if ref_disp[k] > 1e-6}
assert not dead, dead

final = [o for o in rig.children_recursive if o.type == 'MESH' and not o.hide_render]
dg = depsgraph(); total = 0; rows = []
for o in final:
    t = tri_count(o.data); total += t; rows.append((o.name, t, [s.material.name for s in o.material_slots]))
log['final_objects'] = rows; log['final_tris_incl_hidden_render_excluded'] = total
log['export_object_count'] = len(final)
print('FINAL', json.dumps(rows)); print('TOTAL TRIS', total)
# vertices without any skin weight would collapse to the origin in the viewer
for o in final:
    me = o.data; bad = sum(1 for v in me.vertices if not any(g.weight > 0 for g in v.groups))
    assert bad == 0, (o.name, bad)
REPORT.write_text(json.dumps(log, indent=1))
assert Path(bpy.data.filepath).resolve() == V5.resolve()
bpy.ops.wm.save_mainfile()
print('BUILD DONE', V5)
