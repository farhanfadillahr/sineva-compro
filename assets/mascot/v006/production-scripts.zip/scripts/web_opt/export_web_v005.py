"""Export the v005 web GLB from blender/sino_master_v005_web.blend (geometry is already baked/merged by build_v005_web.py).

  Blender -b blender/sino_master_v005_web.blend --python scripts/web_opt/export_web_v005.py -- [out.glb]

Same animation plumbing as scripts/export_web.py, adapted to the merged meshes:
- The head's shape-key datablock was rebuilt (decimation + eyelid join), so the per-clip face values are baked for
  *every* shape-key mesh from the `<clip>__face` actions, sampled on whole frames (the exporter force-samples at
  step 1 anyway, so sampling here loses nothing and avoids interpolation/handle differences).
- Exports only the active scene (the glTF exporter otherwise adds every scene in the file).
"""
import bpy, sys, json, struct
from pathlib import Path

BASE = Path(bpy.data.filepath).resolve().parents[1]
argv = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
OUT = Path(argv[0]) if argv else BASE/'export/web/sino_v005.glb'
OUT.parent.mkdir(parents=True, exist_ok=True)
assert 'v005' in bpy.data.filepath

S = bpy.context.scene
assert len(bpy.data.scenes) == 1
rig = bpy.data.objects['RIG-sino']
S.frame_set(0)
clips = json.loads(rig['clips'])


def fcurves(action):
    for layer in action.layers:
        for strip in layer.strips:
            for slot in action.slots:
                bag = strip.channelbag(slot)
                if bag:
                    for f in bag.fcurves: yield f


sk_objs = [o for o in rig.children if o.type == 'MESH' and o.data.shape_keys and not o.hide_render]
for o in sk_objs:
    kd = o.data.shape_keys
    ad = kd.animation_data or kd.animation_data_create()
    for d in list(ad.drivers): ad.drivers.remove(d)
    for t in list(ad.nla_tracks): ad.nla_tracks.remove(t)
    ad.action = None
    for clip in clips:
        face = bpy.data.actions[clip + '__face']
        curves = [(fc, fc.data_path.split('"')[1]) for fc in fcurves(face)]
        curves = [(fc, n) for fc, n in curves if n in kd.key_blocks]
        if not curves: continue
        a0, a1 = face.frame_range
        for f in range(int(round(a0)), int(round(a1)) + 1):
            for fc, name in curves:
                kb = kd.key_blocks[name]; kb.value = fc.evaluate(f); kb.keyframe_insert('value', frame=f)
        act = ad.action; act.name = f'{o.name}:{clip}'
        tr = ad.nla_tracks.new(); tr.name = clip; tr.strips.new(clip, 0, act)
        ad.action = None
    for kb in kd.key_blocks: kb.value = 0
    print('baked face clips on', o.name, len(kd.key_blocks) - 1, 'keys')

for ad in [rig.animation_data] + [o.data.shape_keys.animation_data for o in sk_objs]:
    ad.action = None
    for t in ad.nla_tracks: t.mute = False; t.is_solo = False

export_objs = [rig] + [o for o in rig.children_recursive if o.type == 'MESH' and not o.hide_render]
for o in bpy.data.objects:
    try: o.select_set(False)
    except RuntimeError: pass
for o in export_objs:
    o.hide_viewport = False; o.hide_set(False); o.select_set(True)
bpy.context.view_layer.objects.active = rig

kw = dict(filepath=str(OUT), export_format='GLB', use_selection=True, use_active_scene=True, export_apply=True,
          export_animations=True, export_animation_mode='NLA_TRACKS', export_force_sampling=True, export_frame_step=1,
          export_def_bones=True, export_morph=True, export_morph_normal=False, export_morph_tangent=False, export_skins=True,
          export_yup=True, export_materials='EXPORT', export_vertex_color='MATERIAL', export_optimize_animation_size=True,
          export_anim_single_armature=True, export_reset_pose_bones=True, export_rest_position_armature=True,
          export_image_format='AUTO', export_texcoords=True, export_normals=True, export_lights=False, export_cameras=False,
          export_extras=False, export_current_frame=False, export_try_sparse_sk=True, export_hierarchy_full_collections=False)
valid = set(bpy.ops.export_scene.gltf.get_rna_type().properties.keys())
dropped = [k for k in kw if k not in valid]
kw = {k: v for k, v in kw.items() if k in valid}
if dropped: print('exporter options not in this Blender, skipped:', dropped)
bpy.ops.export_scene.gltf(**kw)

data = OUT.read_bytes()
length = struct.unpack('<I', data[12:16])[0]; js = json.loads(data[20:20+length])
acc = js['accessors']
tris = sum(acc[p['indices']]['count']//3 for m in js['meshes'] for p in m['primitives'] if 'indices' in p)
print('GLB', OUT, round(len(data)/1e6, 2), 'MB | nodes', len(js['nodes']), 'meshes', len(js['meshes']), 'prims', sum(len(m['primitives']) for m in js['meshes']), 'triangles', tris, 'scenes', len(js['scenes']))
print('EXPORT DONE', flush=True)
