"""Print an inventory of the scene: scenes, mesh objects with evaluated tris, shape keys, modifiers, materials.
Run: Blender -b <file> --python scripts/web_opt/inspect_v005.py"""
import bpy
dg = bpy.context.evaluated_depsgraph_get()
print('SCENES', [(s.name, len(s.objects)) for s in bpy.data.scenes])
print('COLLECTIONS', [(c.name, len(c.objects)) for c in bpy.data.collections])
rig = bpy.data.objects.get('RIG-sino')
rows = []
for o in bpy.context.scene.objects:
    if o.type != 'MESH': continue
    ev = o.evaluated_get(dg); me = ev.to_mesh()
    tris = sum(len(p.vertices) - 2 for p in me.polygons)
    sk = o.data.shape_keys
    rows.append((o.name, tris, len(me.vertices), len(sk.key_blocks) - 1 if sk else 0, [m.type + ('' if m.show_viewport else '(off)') for m in o.modifiers],
                 [s.material.name if s.material else None for s in o.material_slots], o.parent.name if o.parent else None, o.hide_render, o.hide_viewport, list(o.data.color_attributes.keys())))
    ev.to_mesh_clear()
for r in sorted(rows, key=lambda r: -r[1]): print('MESH', r)
print('total tris (evaluated, viewport mods)', sum(r[1] for r in rows), 'objects', len(rows))
print('NON-MESH', [(o.name, o.type) for o in bpy.context.scene.objects if o.type != 'MESH'])
print('OBJECTS NOT IN SCENE', [(o.name, o.type, [s.name for s in o.users_scene]) for o in bpy.data.objects if bpy.context.scene not in o.users_scene])
print('MATERIALS', len(bpy.data.materials))
for m in bpy.data.materials:
    p = next((n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None) if m.node_tree else None
    if p: print('MAT', m.name, m.users, {k: (round(p.inputs[k].default_value, 3) if hasattr(p.inputs[k].default_value, '__float__') else None) for k in ['Alpha','Transmission Weight','Coat Weight','Sheen Weight','Roughness'] if k in p.inputs}, 'blend', getattr(m,'surface_render_method',None))
