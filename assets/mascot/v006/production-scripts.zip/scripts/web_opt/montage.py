"""Place PNGs side by side (left = v004, right = v005) using Blender's image API (no PIL needed).
  Blender -b --python scripts/web_opt/montage.py -- out.png left.png right.png"""
import bpy, sys, numpy as np
out, *srcs = sys.argv[sys.argv.index('--')+1:]
arrs = []
for s in srcs:
    im = bpy.data.images.load(s); w, h = im.size
    arrs.append(np.array(im.pixels[:], dtype=np.float32).reshape(h, w, 4))
H = max(a.shape[0] for a in arrs)
arrs = [np.pad(a, ((0, H - a.shape[0]), (0, 0), (0, 0))) for a in arrs]
m = np.concatenate(arrs, axis=1)
img = bpy.data.images.new('m', m.shape[1], m.shape[0], alpha=True)
img.pixels = m.ravel(); img.filepath_raw = out; img.file_format = 'PNG'; img.save()
print('MONTAGE', out)
