"""Render a GLB in a neutral studio for before/after comparison (EEVEE, headless).

  Blender -b --python scripts/web_opt/render_glb.py -- <in.glb> <out_dir> <tag> [action:frame]

Same camera, lights and world for every file, so differences come from the asset only.
"""
import bpy, sys, math
from pathlib import Path
from mathutils import Vector

glb, out_dir, tag = sys.argv[sys.argv.index('--')+1:][:3]
extra = sys.argv[sys.argv.index('--')+1:][3:]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=glb)
S = bpy.context.scene
rig = next(o for o in S.objects if o.type == 'ARMATURE')
meshes = [o for o in S.objects if o.type == 'MESH']
if extra:   # pose: "clip:frame" -> only that clip's NLA track is audible (rig + every shape-key datablock), importer fps
    clip, frame = extra[0].split(':')
    ads = [rig.animation_data] + [o.data.shape_keys.animation_data for o in meshes if o.data.shape_keys and o.data.shape_keys.animation_data]
    for ad in ads:
        ad.action = None
        for t in ad.nla_tracks: t.mute = (t.name != clip)
    S.frame_set(int(frame))
dg = bpy.context.evaluated_depsgraph_get()
# world / lights
w = bpy.data.worlds.new('w'); S.world = w; w.use_nodes = True
bg = next(n for n in w.node_tree.nodes if n.type == 'BACKGROUND'); bg.inputs[0].default_value = (0.62, 0.66, 0.70, 1); bg.inputs[1].default_value = 1.0
def sun(name, rot, energy, color=(1, 1, 1)):
    d = bpy.data.lights.new(name, 'SUN'); d.energy = energy; d.color = color
    o = bpy.data.objects.new(name, d); S.collection.objects.link(o); o.rotation_euler = [math.radians(a) for a in rot]
sun('key', (50, 0, -35), 3.2); sun('fill', (70, 0, 60), 1.2, (0.85, 0.92, 1.0)); sun('rim', (110, 0, 160), 2.2, (0.5, 0.85, 0.85))
# The mascot is 1 m tall and stands on z=0; bounds from mesh vertices are polluted by stray nodes (v004 has a Cube),
# so frame from fixed values and the head bone instead.
hb = next((rig.matrix_world @ rig.pose.bones[n].head for n in ('DEF-head', 'DEF-head.001') if n in rig.pose.bones), Vector((0, 0, 0.8)))
print('head bone', tuple(hb))
height = 1.1; ctr = Vector((0, 0, 0.55))
lo = Vector((0, 0, 0))
head_z = 0.79
cam_d = bpy.data.cameras.new('cam'); cam = bpy.data.objects.new('cam', cam_d); S.collection.objects.link(cam); S.camera = cam
cam_d.type = 'PERSP'; cam_d.lens = 85
out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
S.render.resolution_x = 900; S.render.resolution_y = 1100; S.render.film_transparent = False
eng = [i.identifier for i in bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items]
S.render.engine = next(e for e in eng if 'EEVEE' in e)
try: S.eevee.taa_render_samples = 24
except Exception: pass
S.view_settings.view_transform = 'Standard' if 'Standard' in [i.identifier for i in bpy.types.ColorManagedViewSettings.bl_rna.properties['view_transform'].enum_items] else S.view_settings.view_transform
def shot(name, az_deg, target, dist, lens=85, res=None):
    cam_d.lens = lens
    az = math.radians(az_deg)
    cam.location = target + Vector((math.sin(az) * dist, -math.cos(az) * dist, 0.0))
    cam.rotation_euler = (target - cam.location).to_track_quat('-Z', 'Y').to_euler()
    if res: S.render.resolution_x, S.render.resolution_y = res
    S.render.filepath = str(out / f'{tag}_{name}.png'); bpy.ops.render.render(write_still=True)
fit = height * 3.1
if extra:
    shot('pose_front', 0, ctr, fit); shot('pose_34', 35, ctr, fit); print('RENDER DONE'); raise SystemExit
shot('front', 0, ctr, fit); shot('34', 35, ctr, fit)
shot('face', 0, Vector((ctr.x, ctr.y, head_z)), 0.9, lens=85, res=(900, 900))
shot('face34', 35, Vector((ctr.x, ctr.y, head_z)), 0.9, lens=85, res=(900, 900))
print('RENDER DONE')
