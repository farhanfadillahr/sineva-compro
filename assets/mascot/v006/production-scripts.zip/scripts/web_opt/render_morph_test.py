"""Render the face close-up with selected morph weights at 1.0 (v004 vs v005 blends) to prove the keys still deform the face.

  Blender -b <file.blend> --python scripts/web_opt/render_morph_test.py -- <out_dir> <tag>

v004: only the head owns the driver sources, lids/lashes follow through drivers. v005: head and the merged
face-detail mesh both carry the keys by name, so the same value is set on every key block with that name.
"""
import bpy, sys
from pathlib import Path
out_dir, tag = sys.argv[sys.argv.index('--')+1:][:2]
S = bpy.context.scene
cases = {'blink': {'eyeBlinkLeft': 1, 'eyeBlinkRight': 1}, 'smile_brows': {'mouthSmileLeft': 1, 'mouthSmileRight': 1, 'browDownLeft': 1, 'browOuterUpRight': 1, 'browInnerUp': .6}, 'jaw_wide': {'jawOpen': 1, 'eyeWideLeft': 1, 'eyeWideRight': 1}}
eng = [i.identifier for i in bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items]
S.render.engine = next(e for e in eng if 'EEVEE' in e)
S.render.resolution_x = S.render.resolution_y = 700; S.render.film_transparent = False
try: S.eevee.taa_render_samples = 16
except Exception: pass
S.camera = bpy.data.objects['CAM-face_cu']
rig = bpy.data.objects['RIG-sino']
rig.animation_data.action = None
for t in rig.animation_data.nla_tracks: t.mute = True
head = bpy.data.objects['GEO-head']
if head.data.shape_keys.animation_data:
    head.data.shape_keys.animation_data.action = None
    for t in head.data.shape_keys.animation_data.nla_tracks: t.mute = True
keyed = [o for o in rig.children if o.type == 'MESH' and o.data.shape_keys]
for case, vals in cases.items():
    for o in keyed:
        for kb in o.data.shape_keys.key_blocks:
            if kb.name in vals: kb.value = vals[kb.name]
    S.frame_set(0)
    S.render.filepath = str(Path(out_dir) / f'morph_{case}_{tag}.png'); bpy.ops.render.render(write_still=True)
    for o in keyed:
        for kb in o.data.shape_keys.key_blocks:
            if kb.name != 'Basis': kb.value = 0
print('MORPH RENDER DONE')
